///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MILESTONE THREE MODIFICATIONS: Ziyan Noorani
//  The desk scene is now built from SceneObject subclasses, one per real-world
//  object, instead of one render method per object inside this class. The
//  scene also gains the monitor and the square pencil cup from the 2D
//  reference photograph, so the plane now situates five objects rather than
//  three.
//
//  MILESTONE FOUR MODIFICATIONS: Ziyan Noorani
//  Loads the scene's texture images at startup, registers each one with the
//  scene objects by tag, and frees them on shutdown.
//
//  MILESTONE FIVE MODIFICATIONS: Ziyan Noorani
//  Lights the scene with the Phong model in the course fragment shader.
//  Four lights stand in for the lighting in a real room with a desk:
//    0  warm overhead room light, the key light
//    1  cool fill from the front right, so no face falls to full black
//    2  daylight from a window behind the desk, which puts the reflected
//       highlight on the desktop between the camera and the monitor
//    3  faint blue glow from the monitor screen onto the keyboard
//
//  Retuned after the first build rendered about three times too bright:
//  the shader counts each material's ambient term once per light, so the
//  ambient strengths dropped to 0.08 and the light colors came down to
//  match. See the comment above SCENE_MATERIALS for the numbers.
//  Each object part names a material, defined here once by tag.
//
//  FINAL PROJECT MODIFICATIONS: Ziyan Noorani
//  Adds the riser shelf and the mousepad from my desk photos and moves the
//  monitor onto the riser. The desk texture is now black.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

#include <fstream>
#include <iostream>
#include <string>

#ifdef _WIN32
#include <direct.h>   // _getcwd, used to report the working directory
#endif

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";

	/***********************************************************
	 *  Scene layout
	 *
	 *  Where each object sits on the desk. The individual
	 *  measurements of each object now live inside that
	 *  object's own class, so all that is left here is the
	 *  arrangement, which is the one thing that genuinely
	 *  belongs to the scene rather than to any single object.
	 *
	 *  The desk is centered on the world origin. Negative Z is
	 *  further from the camera's default position, so the
	 *  monitor sits at the back, the microphone stands in the
	 *  middle, and the keyboard and mouse sit at the front edge
	 *  where they are in the reference photograph.
	 ***********************************************************/
	const glm::vec3 DESK_ORIGIN = glm::vec3(0.0f, 0.0f, 0.0f);

	// back row: the riser along the back edge, with the monitor on top
	const glm::vec3 RISER_ORIGIN = glm::vec3(0.0f, 0.0f, -5.50f);
	const glm::vec3 MONITOR_ORIGIN = glm::vec3(0.0f, 2.00f, -5.50f);   // y = riser top

	// mousepad under the keyboard, mouse and mic. Raised 0.02 above the desk.
	const glm::vec3 MAT_ORIGIN = glm::vec3(0.0f, 0.02f, 3.20f);

	// middle row
	const glm::vec3 MICROPHONE_ORIGIN = glm::vec3(-0.40f, 0.0f, 0.80f);
	const glm::vec3 MUG_ORIGIN = glm::vec3(3.20f, 0.0f, 0.90f);
	const glm::vec3 NOTEBOOK_STACK_ORIGIN = glm::vec3(4.60f, 0.0f, -1.90f);
	const glm::vec3 PENCIL_CUP_ORIGIN = glm::vec3(7.40f, 0.0f, -0.60f);

	// front row
	const glm::vec3 KEYBOARD_ORIGIN = glm::vec3(0.0f, 0.0f, 4.50f);
	const glm::vec3 MOUSE_ORIGIN = glm::vec3(6.10f, 0.0f, 4.00f);
	const glm::vec3 PHONE_STAND_ORIGIN = glm::vec3(-6.20f, 0.0f, 1.80f);

	/***********************************************************
	 *  Scene textures
	 *
	 *  Every image the scene uses, paired with the tag the scene
	 *  objects ask for it by. All images are seamless, square,
	 *  1024 x 1024 textures, so they tile without visible seams.
	 *  mousepad.png is drawn by tools/make_mousepad.py.
	 ***********************************************************/
	struct SceneTextureFile
	{
		const char* fileName;
		const char* tag;
	};

	const SceneTextureFile SCENE_TEXTURES[] =
	{
		{ "desk_black.jpg",  "desk_black" },   // desk surface
		{ "mousepad.png",    "mousepad" },     // mousepad
		{ "stand_metal.jpg", "stand_metal" },  // mic base, post, shock mount
		{ "mic_plastic.jpg", "mic_plastic" },  // mic end caps
		{ "mic_mesh.jpg",    "mic_mesh" }      // mic grille barrel
	};

	const int SCENE_TEXTURE_COUNT = sizeof(SCENE_TEXTURES) / sizeof(SCENE_TEXTURES[0]);

	/***********************************************************
	 *  Texture folder search list
	 *
	 *  The textures folder sits next to the .vcxproj file, but
	 *  the program does not always start in that folder. Visual
	 *  Studio can launch it from the project folder, and a
	 *  double-clicked EXE starts in the Debug or Release folder
	 *  one level below. Checking both means the textures load
	 *  either way, including for whoever runs the submitted EXE.
	 ***********************************************************/
	const char* TEXTURE_FOLDERS[] =
	{
		"textures/",      // launched from the project folder
		"../textures/"    // launched from the Debug or Release folder
	};

	const int TEXTURE_FOLDER_COUNT = sizeof(TEXTURE_FOLDERS) / sizeof(TEXTURE_FOLDERS[0]);

	/***********************************************************
	 *  Scene materials
	 *
	 *  One entry per real-world surface in the scene. Values
	 *  follow the Phong model in the course fragment shader:
	 *  the final color of a surface is the sum of its ambient,
	 *  diffuse and specular terms from every light, multiplied
	 *  by its texture or solid color.
	 *
	 *  Tuned against the running scene. The shader adds each
	 *  material's ambient term once per light, so with four
	 *  lights the ambient value counts four times. The first
	 *  tuning pass assumed it counted once, and the whole scene
	 *  rendered about three times too bright: black plastic came
	 *  out light gray and the desk texture clipped to white. All
	 *  ambient strengths are now 0.08, which keeps an ambient
	 *  floor of roughly 0.4 on faces no light reaches directly,
	 *  and lit faces land near 1.0 so textures show their real
	 *  colors.
	 *
	 *  Rough surfaces (paper, rubber, matte plastic) get low
	 *  specular and low shininess so light spreads evenly;
	 *  polished surfaces (glass, glaze, liquid) get higher values
	 *  so light comes back as a highlight.
	 *
	 *  Field order: ambientStrength, ambientColor, diffuseColor,
	 *  specularColor, shininess, tag.
	 ***********************************************************/
	const float AMBIENT_STRENGTH = 0.08f;

	const ObjectMaterial SCENE_MATERIALS[] =
	{
		// varnished desktop: the plane that reflects light. Diffuse is kept
		// below the other materials because the wood texture is already
		// light; a low shininess spreads the window light into a broad
		// sheen across the grain instead of a mirror spot.
		{ AMBIENT_STRENGTH, glm::vec3(0.70f, 0.64f, 0.56f), glm::vec3(0.68f, 0.64f, 0.60f),
		  glm::vec3(0.48f, 0.44f, 0.38f), 2.5f, "desk_wood" },

		  // mic stand, shock mount, pencil cup, keyboard plate
		  { AMBIENT_STRENGTH, glm::vec3(0.82f, 0.82f, 0.86f), glm::vec3(0.72f, 0.72f, 0.76f),
			glm::vec3(0.90f, 0.90f, 0.95f), 5.0f, "brushed_metal" },

			// monitor shell, keyboard case and keys, scroll wheel
			{ AMBIENT_STRENGTH, glm::vec3(0.85f, 0.85f, 0.85f), glm::vec3(0.85f, 0.85f, 0.85f),
			  glm::vec3(0.30f, 0.30f, 0.30f), 2.0f, "matte_plastic" },

			  // mic end caps. The cap texture is nearly black, and the shader
			  // multiplies the light by the texture, so at normal values the caps
			  // lose every edge. Doubling the response keeps their outline visible
			  // while they still read as black.
			  { AMBIENT_STRENGTH, glm::vec3(2.00f, 2.00f, 2.00f), glm::vec3(2.00f, 2.00f, 2.00f),
				glm::vec3(0.60f, 0.60f, 0.60f), 3.0f, "mic_plastic" },

				// mouse shell, phone body
				{ AMBIENT_STRENGTH, glm::vec3(0.85f, 0.85f, 0.85f), glm::vec3(0.85f, 0.85f, 0.85f),
				  glm::vec3(0.90f, 0.90f, 0.90f), 5.0f, "gloss_plastic" },

				  // white phone stand: bright and mostly diffuse
				  { AMBIENT_STRENGTH, glm::vec3(0.90f, 0.90f, 0.92f), glm::vec3(0.90f, 0.90f, 0.92f),
					glm::vec3(0.40f, 0.40f, 0.40f), 3.0f, "white_plastic" },

					// monitor and phone screens. Shininess dropped from 40 to 6: at 40
					// the highlight burned a white spot into the middle of the monitor.
					{ AMBIENT_STRENGTH, glm::vec3(0.73f, 0.77f, 0.85f), glm::vec3(0.65f, 0.68f, 0.75f),
					  glm::vec3(1.00f, 1.00f, 1.00f), 6.0f, "screen_glass" },

					  // red perforated mic grille. Boosted for the same reason as the caps:
					  // the red mesh texture is dark, and at normal values it turned maroon.
					  { AMBIENT_STRENGTH, glm::vec3(1.60f, 1.50f, 1.50f), glm::vec3(1.60f, 1.50f, 1.50f),
						glm::vec3(0.40f, 0.35f, 0.35f), 3.0f, "mic_mesh" },

						// glazed ceramic mug
						{ AMBIENT_STRENGTH, glm::vec3(0.85f, 0.85f, 0.85f), glm::vec3(0.85f, 0.85f, 0.85f),
						  glm::vec3(0.80f, 0.80f, 0.80f), 6.0f, "ceramic_glaze" },

						  // coffee surface inside the mug. Shininess dropped from 30 to 3: the
						  // old highlight added enough light to turn the brown surface yellow.
						  { AMBIENT_STRENGTH, glm::vec3(0.80f, 0.75f, 0.70f), glm::vec3(0.85f, 0.80f, 0.75f),
							glm::vec3(1.00f, 0.95f, 0.90f), 3.0f, "coffee" },

							// notebook covers: paper, almost no highlight
							{ AMBIENT_STRENGTH, glm::vec3(0.90f, 0.90f, 0.90f), glm::vec3(0.90f, 0.90f, 0.90f),
							  glm::vec3(0.10f, 0.10f, 0.10f), 0.5f, "paper_cover" },

							  // painted pencils
							  { AMBIENT_STRENGTH, glm::vec3(0.90f, 0.90f, 0.90f), glm::vec3(0.90f, 0.90f, 0.90f),
								glm::vec3(0.30f, 0.30f, 0.30f), 2.0f, "painted_wood" },

								// mousepad cloth: flat, no real highlight
								{ AMBIENT_STRENGTH, glm::vec3(0.85f, 0.85f, 0.85f), glm::vec3(0.85f, 0.85f, 0.85f),
								  glm::vec3(0.05f, 0.05f, 0.05f), 0.5f, "mat_cloth" }
	};

	const int SCENE_MATERIAL_COUNT = sizeof(SCENE_MATERIALS) / sizeof(SCENE_MATERIALS[0]);

	/***********************************************************
	 *  Scene lights
	 *
	 *  The course fragment shader sums the Phong result of an
	 *  array of point lights named lightSources. Each entry below
	 *  fills one slot of that array.
	 *
	 *  The shader's lights have no distance falloff, so position
	 *  sets only the direction the light arrives from. That is
	 *  why the window light can sit well behind the desk and
	 *  still light it. It also means a light placed right next to
	 *  a surface paints a bright disc on it, because the angle to
	 *  the light changes quickly across that surface.
	 ***********************************************************/
	struct SceneLight
	{
		glm::vec3 position;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float focalStrength;       // specular exponent: higher = tighter highlight
		float specularIntensity;   // overall strength of the highlight
	};

	// the fragment shader declares this many entries in lightSources[]
	const int SHADER_LIGHT_SLOTS = 4;

	const SceneLight SCENE_LIGHTS[] =
	{
		// 0: key light. Warm white overhead room light, up and to the left
		// in front of the desk, so it lights the tops, the fronts and the
		// left-facing sides at once.
		{
			glm::vec3(-8.0f, 14.0f, 8.0f),
			glm::vec3(0.26f, 0.25f, 0.23f),
			glm::vec3(0.40f, 0.37f, 0.32f),
			glm::vec3(0.60f, 0.56f, 0.50f),
			24.0f,
			0.25f
		},

		// 1: fill light. Dim and cool, from the front right, opposite the
		// key light. It has no highlight of its own; its only job is to
		// keep the sides the key light misses out of complete shadow.
		{
			glm::vec3(12.0f, 7.0f, 12.0f),
			glm::vec3(0.08f, 0.08f, 0.09f),
			glm::vec3(0.15f, 0.17f, 0.22f),
			glm::vec3(0.00f, 0.00f, 0.00f),
			8.0f,
			0.0f
		},

		// 2: window light. Neutral daylight from behind and above the
		// monitor. Placed so its mirror reflection off the desk plane lands
		// in the open area between the keyboard, mic and mug when viewed
		// from the starting camera, which is where the desk sheen shows.
		{
			glm::vec3(4.0f, 10.0f, -20.0f),
			glm::vec3(0.05f, 0.05f, 0.06f),
			glm::vec3(0.20f, 0.21f, 0.24f),
			glm::vec3(1.00f, 1.00f, 1.00f),
			32.0f,
			0.35f
		},

		// 3: monitor glow. A faint blue light from the direction of the
		// screen, tinting the keyboard and desk the way a powered display
		// does in a dim room. It sits 4 units in front of the desk's center
		// line rather than against the screen: placed 1 unit from the glass
		// it painted a bright disc in the middle of the monitor.
		{
			glm::vec3(0.0f, 6.0f, 4.0f),
			glm::vec3(0.00f, 0.00f, 0.00f),
			glm::vec3(0.05f, 0.07f, 0.12f),
			glm::vec3(0.10f, 0.15f, 0.25f),
			16.0f,
			0.05f
		}
	};

	const int SCENE_LIGHT_COUNT = sizeof(SCENE_LIGHTS) / sizeof(SCENE_LIGHTS[0]);

	// catch an extra light at compile time instead of silently ignoring it
	static_assert(SCENE_LIGHT_COUNT <= SHADER_LIGHT_SLOTS,
		"SCENE_LIGHTS has more entries than the fragment shader supports");

	/***********************************************************
	 *  FindTextureFile()
	 *
	 *  Returns the first path in the search list where the file
	 *  exists, or an empty string if it is in none of them.
	 ***********************************************************/
	std::string FindTextureFile(const std::string& fileName)
	{
		for (int index = 0; index < TEXTURE_FOLDER_COUNT; index++)
		{
			std::string candidatePath = std::string(TEXTURE_FOLDERS[index]) + fileName;

			std::ifstream file(candidatePath.c_str());
			if (file.good() == true)
			{
				return(candidatePath);
			}
		}

		return(std::string());
	}

	/***********************************************************
	 *  PrintWorkingDirectory()
	 *
	 *  Prints the folder the program is running from. Relative
	 *  paths such as "textures/" are measured from this folder,
	 *  so it is the first thing to check when a file will not
	 *  load.
	 ***********************************************************/
	void PrintWorkingDirectory()
	{
#ifdef _WIN32
		char buffer[1024];
		if (_getcwd(buffer, sizeof(buffer)) != NULL)
		{
			std::cout << "Working directory: " << buffer << std::endl;
		}
#endif
	}
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	// the texture counter must start at zero or the texture lookup
	// loops below will read uninitialized array entries
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// the scene objects hold pointers into the mesh library, so they
	// have to be released before the mesh library itself
	DestroySceneObjects();

	// release the texture memory on the graphics card
	DestroyGLTextures();
	SceneObject::ClearTextureSlots();
	SceneObject::ClearMaterials();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		// Grayscale images (1 channel, or 2 with alpha) are common for metal
		// and grate textures, but the upload below only handles RGB and RGBA.
		// Reloading with STBI_rgb has stb_image copy the gray value into all
		// three color channels, so the image uploads as ordinary RGB.
		if ((colorChannels == 1) || (colorChannels == 2))
		{
			stbi_image_free(image);
			image = stbi_load(filename, &width, &height, &colorChannels, STBI_rgb);
			colorChannels = 3;

			if (image == NULL)
			{
				std::cout << "Could not convert grayscale image:" << filename << std::endl;
				return false;
			}
		}

		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	// stb_image records why the load failed, for example "can't fopen"
	// for a bad path or an unsupported format for a bad file
	std::cout << "Could not load image:" << filename
		<< " (reason: " << stbi_failure_reason() << ")" << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// glDeleteTextures releases the slot; glGenTextures would have
		// allocated a new one and leaked the old handle
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	// size_t matches the vector's size type, which clears the
	// signed/unsigned comparison warning in the template code
	size_t index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	// report whether the tag was actually matched so callers do not
	// push an uninitialized material into the shader
	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	// matrices are applied right to left, so the mesh is scaled first,
	// then rotated about its own origin, and only then moved into place
	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering.
 *
 *  Preparation happens in steps that are deliberately kept
 *  apart: meshes, textures, materials and lights are shader
 *  resources, and building the objects is a scene concern.
 *  Textures and materials are registered before the objects
 *  are built so every tag exists before any object asks for
 *  it. Lights are set once here because the shader keeps
 *  uniform values between frames and the lights never move.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneMeshes();
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();
	BuildSceneObjects();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Stores every entry in SCENE_MATERIALS in the template's
 *  material list and registers it with the scene objects, so
 *  both the manager and the objects can look it up by tag.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	for (int index = 0; index < SCENE_MATERIAL_COUNT; index++)
	{
		m_objectMaterials.push_back(SCENE_MATERIALS[index]);
		SceneObject::RegisterMaterial(SCENE_MATERIALS[index]);
	}
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Copies every entry in SCENE_LIGHTS into the matching slot
 *  of the shader's lightSources array, then switches lighting
 *  on. Slots without an entry keep their default value of
 *  zero, so they add nothing to the scene.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	for (int index = 0; index < SCENE_LIGHT_COUNT; index++)
	{
		const SceneLight& light = SCENE_LIGHTS[index];

		// builds "lightSources[0]." and so on for this slot
		std::string prefix = "lightSources[" + std::to_string(index) + "].";

		m_pShaderManager->setVec3Value((prefix + "position").c_str(), light.position);
		m_pShaderManager->setVec3Value((prefix + "ambientColor").c_str(), light.ambientColor);
		m_pShaderManager->setVec3Value((prefix + "diffuseColor").c_str(), light.diffuseColor);
		m_pShaderManager->setVec3Value((prefix + "specularColor").c_str(), light.specularColor);
		m_pShaderManager->setFloatValue((prefix + "focalStrength").c_str(), light.focalStrength);
		m_pShaderManager->setFloatValue((prefix + "specularIntensity").c_str(), light.specularIntensity);
	}

	// the shader ignores every value above until this flag is set
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Finds each image in SCENE_TEXTURES, loads it, binds the
 *  loaded textures to texture slots, and tells the scene
 *  objects which slot each tag landed in.
 *
 *  A file that cannot be found or loaded is reported in the
 *  console and skipped. Any part that asks for its tag is then
 *  drawn in magenta, so the problem is visible without
 *  crashing.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bAnyFileMissing = false;

	for (int index = 0; index < SCENE_TEXTURE_COUNT; index++)
	{
		const SceneTextureFile& textureFile = SCENE_TEXTURES[index];
		std::string texturePath = FindTextureFile(textureFile.fileName);

		if (texturePath.empty() == true)
		{
			std::cout << "Texture not found in any textures folder: "
				<< textureFile.fileName << std::endl;
			bAnyFileMissing = true;
			continue;
		}

		if (CreateGLTexture(texturePath.c_str(), textureFile.tag) == true)
		{
			SceneObject::RegisterTextureSlot(
				textureFile.tag,
				FindTextureSlot(textureFile.tag));
		}
	}

	// the search folders are relative, so show where they were measured from
	if (bAnyFileMissing == true)
	{
		PrintWorkingDirectory();
	}

	// once every image is in memory, bind each one to its texture unit
	BindGLTextures();
}

/***********************************************************
 *  LoadSceneMeshes()
 *
 *  Loads the vertex data for every mesh type the scene draws.
 *
 *  Each mesh is loaded exactly once no matter how many times
 *  it is drawn per frame. Five mesh types cover the whole
 *  scene:
 *    plane     the desk surface
 *    box       monitor, notebooks, pencil cup, keyboard,
 *              phone stand
 *    cylinder  mug, pencils, microphone, scroll wheel
 *    torus     mug handle, microphone shock mount
 *    sphere    mouse shell
 ***********************************************************/
void SceneManager::LoadSceneMeshes()
{
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 *  BuildSceneObjects()
 *
 *  Creates one object per real-world item in the 2D reference
 *  photograph and stores it in draw order.
 *
 *  The desk surface is added first because it is the base the
 *  rest of the scene sits on, both visually and in terms of
 *  where every other object's origin is measured from.
 ***********************************************************/
void SceneManager::BuildSceneObjects()
{
	m_sceneObjects.push_back(new DeskSurface(m_pShaderManager, m_basicMeshes, DESK_ORIGIN));
	m_sceneObjects.push_back(new DeskMat(m_pShaderManager, m_basicMeshes, MAT_ORIGIN));
	m_sceneObjects.push_back(new RiserShelf(m_pShaderManager, m_basicMeshes, RISER_ORIGIN));
	m_sceneObjects.push_back(new Monitor(m_pShaderManager, m_basicMeshes, MONITOR_ORIGIN));
	m_sceneObjects.push_back(new NotebookStack(m_pShaderManager, m_basicMeshes, NOTEBOOK_STACK_ORIGIN));
	m_sceneObjects.push_back(new PencilCup(m_pShaderManager, m_basicMeshes, PENCIL_CUP_ORIGIN));
	m_sceneObjects.push_back(new CoffeeMug(m_pShaderManager, m_basicMeshes, MUG_ORIGIN));
	m_sceneObjects.push_back(new Microphone(m_pShaderManager, m_basicMeshes, MICROPHONE_ORIGIN));
	m_sceneObjects.push_back(new Keyboard(m_pShaderManager, m_basicMeshes, KEYBOARD_ORIGIN));
	m_sceneObjects.push_back(new Mouse(m_pShaderManager, m_basicMeshes, MOUSE_ORIGIN));
	m_sceneObjects.push_back(new PhoneStand(m_pShaderManager, m_basicMeshes, PHONE_STAND_ORIGIN));
}

/***********************************************************
 *  DestroySceneObjects()
 *
 *  Frees every object in the scene.
 *
 *  The vector holds raw pointers to heap allocations, so
 *  clearing the vector alone would leak every object. Each one
 *  is deleted first, then the vector is emptied so a second
 *  call cannot delete the same pointer twice.
 ***********************************************************/
void SceneManager::DestroySceneObjects()
{
	for (size_t index = 0; index < m_sceneObjects.size(); index++)
	{
		delete m_sceneObjects[index];
		m_sceneObjects[index] = NULL;
	}

	m_sceneObjects.clear();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes.
 *
 *  The loop does not name any object, so adding the keyboard,
 *  the lamp, or anything else from the reference photograph
 *  later will not require editing this method at all.
 ***********************************************************/
void SceneManager::RenderScene()
{
	for (size_t index = 0; index < m_sceneObjects.size(); index++)
	{
		m_sceneObjects[index]->Draw();
	}
}