#include <iostream>         // error handling and output
#include <cstdlib>          // EXIT_FAILURE
#include <fstream>          // checking which shader folder exists
#include <string>

#include <GL/glew.h>        // GLEW library
#include "GLFW/glfw3.h"     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

// Namespace for declaring global variables
namespace
{
	// Macro for window title
	const char* const WINDOW_TITLE = "7-1 FinalProject and Milestones";

	// Main GLFW window
	GLFWwindow* g_Window = nullptr;

	// scene manager object for managing the 3D scene prepare and render
	SceneManager* g_SceneManager = nullptr;
	// shader manager object for dynamic interaction with the shader code
	ShaderManager* g_ShaderManager = nullptr;
	// view manager object for managing the 3D view setup and projection to 2D
	ViewManager* g_ViewManager = nullptr;
}

// Function declarations - all functions that are called manually
// need to be pre-declared at the beginning of the source code.
bool InitializeGLFW();
bool InitializeGLEW();
std::string FindShaderFolder();

/***********************************************************
 *  Shader folder search list
 *
 *  Relative paths are measured from the folder the program
 *  starts in, and that changes with how it is launched:
 *
 *    shaders/                      a shaders folder copied into
 *                                  the project folder, launched
 *                                  from Visual Studio
 *    ../shaders/                   that same copy, with the EXE
 *                                  double-clicked in Debug or
 *                                  Release
 *    ../../Utilities/shaders/      the course folder, launched
 *                                  from Visual Studio (the
 *                                  template's original path)
 *    ../../../Utilities/shaders/   the course folder, with the
 *                                  EXE double-clicked in Debug
 *                                  or Release
 *
 *  The local copies are checked first so a submitted ZIP runs
 *  on its own, without the rest of CS330Content beside it.
 ***********************************************************/
namespace
{
	const char* SHADER_FOLDERS[] =
	{
		"shaders/",
		"../shaders/",
		"../../Utilities/shaders/",
		"../../../Utilities/shaders/"
	};

	const int SHADER_FOLDER_COUNT = sizeof(SHADER_FOLDERS) / sizeof(SHADER_FOLDERS[0]);
}


/***********************************************************
 *  main(int, char*)
 *
 *  This function gets called after the application has been
 *  launched.
 ***********************************************************/
int main(int argc, char* argv[])
{
	// if GLFW fails initialization, then terminate the application
	if (InitializeGLFW() == false)
	{
		return(EXIT_FAILURE);
	}

	// try to create a new shader manager object
	g_ShaderManager = new ShaderManager();
	// try to create a new view manager object
	g_ViewManager = new ViewManager(
		g_ShaderManager);

	// try to create the main display window
	g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);

	// if GLEW fails initialization, then terminate the application
	if (InitializeGLEW() == false)
	{
		return(EXIT_FAILURE);
	}

	// find the folder holding the GLSL files, which depends on where the
	// program was started from (see FindShaderFolder below)
	std::string shaderFolder = FindShaderFolder();
	if (shaderFolder.empty() == true)
	{
		std::cerr << "ERROR: could not find vertexShader.glsl in any shader folder" << std::endl;
		return(EXIT_FAILURE);
	}

	std::string vertexShaderPath = shaderFolder + "vertexShader.glsl";
	std::string fragmentShaderPath = shaderFolder + "fragmentShader.glsl";
	std::cout << "INFO: Loading shaders from " << shaderFolder << std::endl;

	// load the shader code from the external GLSL files
	g_ShaderManager->LoadShaders(
		vertexShaderPath.c_str(),
		fragmentShaderPath.c_str());
	g_ShaderManager->use();

	// try to create a new scene manager object and prepare the 3D scene
	g_SceneManager = new SceneManager(g_ShaderManager);
	g_SceneManager->PrepareScene();

	// loop will keep running until the application is closed 
	// or until an error has occurred
	while (!glfwWindowShouldClose(g_Window))
	{
		// Enable z-depth
		glEnable(GL_DEPTH_TEST);

		// Clear the frame and z buffers
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// convert from 3D object space to 2D view
		g_ViewManager->PrepareSceneView();

		// refresh the 3D scene
		g_SceneManager->RenderScene();


		// Flips the the back buffer with the front buffer every frame.
		glfwSwapBuffers(g_Window);

		// query the latest GLFW events
		glfwPollEvents();
	}

	// clear the allocated manager objects from memory
	if (NULL != g_SceneManager)
	{
		delete g_SceneManager;
		g_SceneManager = NULL;
	}
	if (NULL != g_ViewManager)
	{
		delete g_ViewManager;
		g_ViewManager = NULL;
	}
	if (NULL != g_ShaderManager)
	{
		delete g_ShaderManager;
		g_ShaderManager = NULL;
	}

	// Terminates the program successfully
	exit(EXIT_SUCCESS);
}

/***********************************************************
 *	InitializeGLFW()
 *
 *  This function is used to initialize the GLFW library.
 ***********************************************************/
bool InitializeGLFW()
{
	// GLFW: initialize and configure library
	// --------------------------------------
	glfwInit();

#ifdef __APPLE__
	// set the version of OpenGL and profile to use
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
	// set the version of OpenGL and profile to use
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif
	// GLFW: end -------------------------------

	return(true);
}

/***********************************************************
 *	FindShaderFolder()
 *
 *  Returns the first folder in SHADER_FOLDERS that contains
 *  vertexShader.glsl, or an empty string if none does.
 ***********************************************************/
std::string FindShaderFolder()
{
	for (int index = 0; index < SHADER_FOLDER_COUNT; index++)
	{
		std::string candidate = std::string(SHADER_FOLDERS[index]) + "vertexShader.glsl";

		std::ifstream file(candidate.c_str());
		if (file.good() == true)
		{
			return(std::string(SHADER_FOLDERS[index]));
		}
	}

	return(std::string());
}

/***********************************************************
 *	InitializeGLEW()
 *
 *  This function is used to initialize the GLEW library.
 ***********************************************************/
bool InitializeGLEW()
{
	// GLEW: initialize
	// -----------------------------------------
	GLenum GLEWInitResult = GLEW_OK;

	// try to initialize the GLEW library
	GLEWInitResult = glewInit();
	if (GLEW_OK != GLEWInitResult)
	{
		std::cerr << glewGetErrorString(GLEWInitResult) << std::endl;
		return false;
	}
	// GLEW: end -------------------------------

	// Displays a successful OpenGL initialization message
	std::cout << "INFO: OpenGL Successfully Initialized\n";
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n" << std::endl;

	return(true);
}