///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MILESTONE THREE MODIFICATIONS: Ziyan Noorani
//  Adds keyboard navigation, mouse-driven camera orientation, scroll wheel
//  speed control, and a runtime switch between perspective and orthographic
//  projection.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h"

/***********************************************************
 *  ViewManager
 *
 *  Owns the display window and the single virtual camera.
 *  Each frame it reads the keyboard, applies any queued mouse
 *  input, and hands the resulting view and projection matrices
 *  to the shader.
 *
 *  Controls:
 *    W / S    move forward / backward
 *    A / D    move left / right
 *    Q / E    move up / down
 *    Mouse    look around (yaw and pitch)
 *    Scroll   increase / decrease movement speed
 *    P        perspective (3D) projection
 *    O        orthographic (2D) projection
 *    ESC      close the window
 ***********************************************************/
class ViewManager
{
public:
	// constructor
	ViewManager(
		ShaderManager* pShaderManager);
	// destructor
	~ViewManager();

	// mouse position callback for mouse interaction with the 3D scene
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

	// mouse scroll callback, used to adjust how fast the camera travels
	static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// active OpenGL display window
	GLFWwindow* m_pWindow;

	// process keyboard events for interaction with the 3D scene
	void ProcessKeyboardEvents();

	// move the camera straight up or down along the world up axis
	void ProcessVerticalMovement(float verticalDirection);

	// recompute the camera direction vectors after a programmatic
	// change to the yaw or pitch angles
	void ApplyCameraOrientation(float yawDegrees, float pitchDegrees);

	// reposition the camera for the requested projection mode
	void SwitchProjectionMode(bool bUsePerspective);

	// build the projection matrix that matches the active mode
	glm::mat4 BuildProjectionMatrix() const;

public:
	// create the initial OpenGL display window
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);

	// prepare the conversion from 3D object display to 2D scene display
	void PrepareSceneView();
};