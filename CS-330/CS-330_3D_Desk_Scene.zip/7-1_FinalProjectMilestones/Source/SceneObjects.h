///////////////////////////////////////////////////////////////////////////////
// SceneObjects.h
// ==============
// The objects that make up the 3D desk scene.
//
//  AUTHOR: Ziyan Noorani
//  CS-330 Computational Graphics and Visualization, SNHU
//
//  Milestone Two split the scene into one render method per object. Feedback
//  on that submission asked for those methods to become classes, so each
//  object is now a class that owns its own measurements, its own colors, and
//  its own drawing code. A change to the mug cannot reach the notebooks, and
//  a new object can be added without editing any existing object.
//
//  SceneObject is the abstract base. One class follows for each real-world
//  object in the 2D reference photograph:
//    DeskSurface    the plane every other object rests on
//    Monitor        the display at the back of the desk
//    CoffeeMug      the black mug, the complex object from Milestone Two
//    NotebookStack  the stacked notebooks beside the mug
//    PencilCup      the square cup and the pencils standing in it
//    Keyboard, Mouse, PhoneStand
//    Microphone     the HyperX mic on its stand, the textured complex
//                   object for Milestone Four
//
//  MILESTONE FOUR MODIFICATIONS: Ziyan Noorani
//  SceneObject can now draw with textures as well as solid colors. The desk
//  surface is textured with tiled wood, and every part of the microphone is
//  textured to match the component it represents.
//
//  MILESTONE FIVE MODIFICATIONS: Ziyan Noorani
//  Adds Phong lighting support. Every part of every object now names the
//  material it is made of (wood, brushed metal, matte plastic, glass, and so
//  on), and SceneObject sends that material to the shader before each draw.
//  Materials are registered by tag once at startup, the same way textures
//  are, so an object asks for "brushed_metal" without knowing its numbers.
//
//  FINAL PROJECT MODIFICATIONS: Ziyan Noorani
//  Adds RiserShelf (the shelf the monitor stands on in my desk photos) and
//  DeskMat (the mousepad). The desk now uses a black texture to match the
//  photos.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <glm/glm.hpp>

#include <map>
#include <string>

/***********************************************************
 *  ObjectMaterial
 *
 *  The surface properties the fragment shader's Phong model
 *  reads for the next draw command.
 *
 *    ambientColor     tint of the light the surface returns
 *                     when no light hits it directly
 *    ambientStrength  how much of that ambient light it returns
 *    diffuseColor     how strongly it scatters direct light
 *    specularColor    color of its highlights
 *    shininess        how much specular light it reflects
 *    tag              the name objects ask for it by
 *
 *  Defined here rather than inside SceneManager so the scene
 *  objects can use it without including SceneManager.h, which
 *  already includes this file.
 ***********************************************************/
struct ObjectMaterial
{
	float ambientStrength;
	glm::vec3 ambientColor;
	glm::vec3 diffuseColor;
	glm::vec3 specularColor;
	float shininess;
	std::string tag;
};

/***********************************************************
 *  SceneObject
 *
 *  Abstract base class. It supplies the two operations every
 *  object needs from the shader, pushing a transform and
 *  pushing a color, and requires each derived class to supply
 *  its own Draw().
 *
 *  The shader pointer and the mesh library are passed in rather
 *  than created here, because both are shared across the whole
 *  scene. An object that created its own mesh library would
 *  reload the same vertex data once per object.
 ***********************************************************/
class SceneObject
{
public:
	SceneObject(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual ~SceneObject();

	// each object knows how to draw itself from its own primitives
	virtual void Draw() = 0;

	// the point on the desk this object is built around
	glm::vec3 GetOrigin() const;
	void SetOrigin(glm::vec3 origin);

	// Records which OpenGL texture slot holds the texture with this tag.
	// The SceneManager calls this once per texture after loading it, so
	// objects can ask for a texture by name without knowing slot numbers.
	static void RegisterTextureSlot(const std::string& textureTag, int textureSlot);

	// forgets every registered texture, called when the textures are freed
	static void ClearTextureSlots();

	// Records a material under its tag. The SceneManager calls this once per
	// material at startup, so objects can ask for a material by name.
	static void RegisterMaterial(const ObjectMaterial& material);

	// forgets every registered material, called when the scene shuts down
	static void ClearMaterials();

protected:
	// build a model matrix from scale, rotation and position values,
	// then send it to the shader for the next draw command
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// send a solid color to the shader for the next draw command
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// convert an offset measured from this object's own origin into a
	// world-space position, applying the object's yaw so that every part
	// of a multi-part object stays attached when the yaw is changed
	glm::vec3 LocalToWorld(glm::vec3 localOffset, float yawDegrees) const;

	// send a registered texture to the shader for the next draw command.
	// The UV scale is reset to 1 x 1 so a tiling value set by an earlier
	// part never leaks into this one.
	void SetShaderTexture(const std::string& textureTag);

	// how many times the texture repeats across the mesh in U and V
	void SetTextureUVScale(float uScale, float vScale);

	// Draws a cylinder mesh with the current transform and texture, tiled
	// so one texture repeat covers tileSize scene units on every surface.
	// The sides and the end caps are tiled separately: the side wraps around
	// the circumference, the caps span the diameter, and one shared UV scale
	// would stretch the texture across one or the other.
	void DrawTiledCylinder(float radius, float height, float tileSize);

	// send the registered material with this tag to the shader for the next
	// draw command. Materials stay set between draws, so every part sets its
	// own rather than inheriting whatever the previous part used.
	void SetShaderMaterial(const std::string& materialTag);

	// shared shader manager, owned by the caller
	ShaderManager* m_pShaderManager;
	// shared basic mesh library, owned by the caller
	ShapeMeshes* m_pShapeMeshes;
	// world-space anchor point for this object
	glm::vec3 m_origin;

private:
	// texture tag -> texture slot, shared by every object. Textures are
	// loaded once for the whole scene, the same way the meshes are.
	static std::map<std::string, int> s_textureSlots;

	// material tag -> material values, shared by every object
	static std::map<std::string, ObjectMaterial> s_materials;
};

/***********************************************************
 *  DeskSurface
 *
 *  The flat desktop that situates the whole scene. Drawn first
 *  so everything else appears to rest on top of it.
 ***********************************************************/
class DeskSurface : public SceneObject
{
public:
	DeskSurface(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	// the plane mesh spans one unit in each direction, so these values
	// are half-extents: the finished desk is twice this wide and deep
	static const float SURFACE_HALF_WIDTH;
	static const float SURFACE_HALF_DEPTH;

	// scene units covered by one repeat of the wood texture
	static const float WOOD_TILE_SIZE;
};

/***********************************************************
 *  RiserShelf
 *
 *  The shelf along the back of the desk that the monitor sits
 *  on. One wide box for the shelf and four thin boxes for legs.
 ***********************************************************/
class RiserShelf : public SceneObject
{
public:
	RiserShelf(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

	// height of the top of the shelf, so the monitor can sit on it
	static const float TOP_HEIGHT;

private:
	static const glm::vec3 SHELF_SCALE;
	static const glm::vec3 LEG_SCALE;
	// how far in from the corners the legs are
	static const float LEG_INSET;

	// draws one leg at the corner picked by the two signs (+1 or -1)
	void DrawLeg(float xSign, float zSign);
};

/***********************************************************
 *  DeskMat
 *
 *  The mousepad under the keyboard and mouse. A plane with the
 *  topographic mousepad texture tiled across it.
 ***********************************************************/
class DeskMat : public SceneObject
{
public:
	DeskMat(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	// half extents, since the plane mesh goes from -1 to 1
	static const float HALF_WIDTH;
	static const float HALF_DEPTH;

	// scene units covered by one repeat of the texture
	static const float TILE_SIZE;
};

/***********************************************************
 *  Monitor
 *
 *  The display at the back of the desk, built from four boxes:
 *  a base, a supporting neck, the bezel, and the screen face.
 ***********************************************************/
class Monitor : public SceneObject
{
public:
	Monitor(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	static const float YAW_DEGREES;

	static const glm::vec3 BASE_SCALE;
	static const glm::vec3 NECK_SCALE;
	static const glm::vec3 BEZEL_SCALE;
	static const glm::vec3 SCREEN_SCALE;

	// how far the screen panel sits above the desk surface
	static const float SCREEN_BOTTOM_HEIGHT;

	// how far back from the base center the panel is set, so the screen
	// does not overhang the front edge of its own stand
	static const float PANEL_DEPTH_OFFSET;
};

/***********************************************************
 *  CoffeeMug
 *
 *  The complex object from Milestone Two: a black ceramic mug
 *  assembled from four cylinders and one torus.
 ***********************************************************/
class CoffeeMug : public SceneObject
{
public:
	CoffeeMug(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	// The mug is turned away from the camera's forward axis so the handle
	// swings toward the viewer's right instead of hiding behind the body.
	// The angle is negative because a positive Y rotation would push the
	// handle away from the camera.
	static const float YAW_DEGREES;

	static const float BODY_RADIUS;
	static const float BODY_HEIGHT;

	// the foot and lip bands are slightly wider than the body, which is
	// what gives a ceramic mug its stepped silhouette in the reference photo
	static const float BAND_RADIUS;
	static const float BAND_HEIGHT;

	// the visible coffee surface sits just above the body's top cap
	static const float COFFEE_RADIUS;
	static const float COFFEE_HEIGHT;

	// handle ring measured from the mug's base center
	static const float HANDLE_RING_RADIUS;
	static const float HANDLE_TUBE_DEPTH;
	static const glm::vec3 HANDLE_OFFSET;

	// the mug is assembled from the bottom up, one part per method
	void DrawFootBand();
	void DrawBody();
	void DrawLipBand();
	void DrawCoffeeSurface();
	void DrawHandle();
};

/***********************************************************
 *  NotebookStack
 *
 *  The stacked notebooks beside the mug. Each cover is drawn
 *  from the same box mesh at a different size, height and yaw.
 ***********************************************************/
class NotebookStack : public SceneObject
{
public:
	NotebookStack(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	static const glm::vec3 LOWER_SCALE;
	static const glm::vec3 UPPER_SCALE;
	static const float LOWER_YAW;
	static const float UPPER_YAW;

	// draws one notebook resting on top of whatever is below it
	void DrawNotebook(
		glm::vec3 scale,
		float yawDegrees,
		float restingHeight,
		glm::vec3 offsetFromOrigin,
		float red,
		float green,
		float blue);
};

/***********************************************************
 *  PencilCup
 *
 *  The square pencil cup and the pencils standing in it. The
 *  cup is a box; each pencil is a thin cylinder tilted about
 *  its own base so the tilt pivots inside the cup rather than
 *  swinging the whole pencil sideways.
 ***********************************************************/
class PencilCup : public SceneObject
{
public:
	PencilCup(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	static const float YAW_DEGREES;
	static const glm::vec3 CUP_SCALE;

	static const float PENCIL_RADIUS;
	static const float PENCIL_LENGTH;
	// pencils start below the cup rim so no gap shows between a
	// pencil and the cup that is supposed to be holding it
	static const float PENCIL_BASE_HEIGHT;

	void DrawCup();

	// draws one pencil leaning by the given tilt angles
	void DrawPencil(
		glm::vec3 offsetFromOrigin,
		float tiltXDegrees,
		float tiltZDegrees,
		float red,
		float green,
		float blue);
};

/***********************************************************
 *  Keyboard
 *
 *  The mechanical keyboard in front of the monitor. Built as a
 *  case, a mounting plate, and five key rows.
 *
 *  Individual keycaps are not modeled. Eighty-seven boxes would
 *  cost eighty-seven draw calls per frame to produce detail
 *  that is smaller than a pixel from any camera position the
 *  scene actually uses. Five row strips with the plate showing
 *  between them read as a keyboard at this scale.
 ***********************************************************/
class Keyboard : public SceneObject
{
public:
	Keyboard(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	static const float YAW_DEGREES;

	static const glm::vec3 CASE_SCALE;
	static const glm::vec3 PLATE_SCALE;
	static const glm::vec3 KEY_ROW_SCALE;

	// number of key rows and how far apart their centers sit
	static const int KEY_ROW_COUNT;
	static const float KEY_ROW_SPACING;

	void DrawCase();
	void DrawPlate();
	void DrawKeyRows();
};

/***********************************************************
 *  Microphone
 *
 *  The condenser microphone on its desk stand: a weighted
 *  base, a post, a shock mount ring, and the red mesh body
 *  capped at both ends.
 *
 *  Textured by component:
 *    base, post, shock mount  dark brushed metal
 *    end caps                 black matte plastic
 *    barrel                   red perforated mesh, tiled
 ***********************************************************/
class Microphone : public SceneObject
{
public:
	Microphone(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	static const float YAW_DEGREES;

	static const float BASE_RADIUS;
	static const float BASE_HEIGHT;
	static const float POST_RADIUS;
	static const float POST_HEIGHT;

	static const float BODY_RADIUS;
	static const float BODY_HEIGHT;
	static const float CAP_RADIUS;
	static const float CAP_HEIGHT;

	static const float MOUNT_RING_RADIUS;
	static const float MOUNT_RING_THICKNESS;

	// Scene units covered by one repeat of each texture. The stand parts
	// share one value so the metal grain is the same size where the post
	// meets the base. The mesh tile is small so the holes read at real size.
	static const float METAL_TILE_SIZE;
	static const float PLASTIC_TILE_SIZE;
	static const float MESH_TILE_SIZE;

	void DrawStand();
	void DrawBody();
	void DrawShockMount();
};

/***********************************************************
 *  Mouse
 *
 *  The mouse beside the keyboard. A sphere squashed on two
 *  axes gives the domed shell its shape in one draw call,
 *  which no combination of boxes would manage.
 ***********************************************************/
class Mouse : public SceneObject
{
public:
	Mouse(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	static const float YAW_DEGREES;
	static const glm::vec3 SHELL_SCALE;
	static const float WHEEL_RADIUS;
	static const float WHEEL_WIDTH;
};

/***********************************************************
 *  PhoneStand
 *
 *  The folding phone stand and the phone resting in it. The
 *  stand arm and the phone share one lean angle, so changing
 *  LEAN_DEGREES tilts the whole assembly together.
 ***********************************************************/
class PhoneStand : public SceneObject
{
public:
	PhoneStand(
		ShaderManager* pShaderManager,
		ShapeMeshes* pShapeMeshes,
		glm::vec3 origin);

	virtual void Draw();

private:
	static const float YAW_DEGREES;

	// how far back the phone and the supporting arm lean, in degrees.
	// Negative tilts the top away from the camera.
	static const float LEAN_DEGREES;

	static const glm::vec3 BASE_SCALE;
	static const glm::vec3 LIP_SCALE;
	static const glm::vec3 ARM_SCALE;
	static const glm::vec3 PHONE_SCALE;
	static const glm::vec3 SCREEN_SCALE;

	void DrawStand();
	void DrawPhone();

	// returns the center position of an object of the given height that
	// leans back by LEAN_DEGREES while its lower edge stays planted at
	// restingHeight. Without this the lean would swing the whole object
	// sideways instead of pivoting it on the stand.
	glm::vec3 LeaningCenter(float objectHeight, float restingHeight) const;
};