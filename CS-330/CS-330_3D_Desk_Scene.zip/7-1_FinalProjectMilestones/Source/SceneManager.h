///////////////////////////////////////////////////////////////////////////////
// shadermanager.h
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MILESTONE THREE MODIFICATIONS: Ziyan Noorani
//  Milestone Two split the scene into one render method per object. Feedback
//  on that submission asked for those methods to become classes, so the scene
//  is now a list of SceneObject instances that the manager builds once and
//  draws each frame. SceneManager no longer knows anything about mug radii or
//  notebook thicknesses: adding an object to the scene means writing a new
//  class and adding one line to PrepareScene().
//
//  MILESTONE FIVE MODIFICATIONS: Ziyan Noorani
//  Adds DefineObjectMaterials() and SetupSceneLights() for Phong lighting.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include "SceneObjects.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager* pShaderManager);
	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	// The material struct now lives in SceneObjects.h so the scene objects
	// can set their own materials. The template's name is kept as an alias
	// so FindMaterial() and SetShaderMaterial() compile unchanged.
	typedef ObjectMaterial OBJECT_MATERIAL;

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// every object in the scene, in the order it is drawn.
	// SceneManager owns these and deletes them in its destructor.
	std::vector<SceneObject*> m_sceneObjects;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// set the transformation values
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);

	// load every mesh the scene objects draw with. Each mesh is loaded
	// once no matter how many objects draw it.
	void LoadSceneMeshes();

	// load every texture image the scene objects draw with, bind them to
	// texture slots, and register each slot with the scene objects
	void LoadSceneTextures();

	// define the surface materials the scene objects are made of and
	// register each one with the scene objects by tag
	void DefineObjectMaterials();

	// configure the Phong light sources in the fragment shader and
	// switch lighting on
	void SetupSceneLights();

	// build the objects that make up the desk scene
	void BuildSceneObjects();

	// free every scene object
	void DestroySceneObjects();

public:

	// The following methods are for the students to
	// customize for their own 3D scene
	void PrepareScene();
	void RenderScene();

};