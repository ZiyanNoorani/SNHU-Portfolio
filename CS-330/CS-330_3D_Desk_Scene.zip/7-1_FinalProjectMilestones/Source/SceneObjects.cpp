///////////////////////////////////////////////////////////////////////////////
// SceneObjects.cpp
// ================
// The objects that make up the 3D desk scene.
//
//  AUTHOR: Ziyan Noorani
//  CS-330 Computational Graphics and Visualization, SNHU
//
//  Scale note: one scene unit is roughly 1.5 inches, which makes the
//  1.9-unit mug body about the height of a real 12 oz mug and the 12-unit
//  monitor panel about the width of a real 24 inch display.
//
//  MILESTONE FOUR MODIFICATIONS: Ziyan Noorani
//  Adds texture support to SceneObject and textures the desk surface and the
//  microphone. Every tile size below is in scene units, so a texture repeat
//  covers the same real-world area no matter which part it is drawn on.
//
//  MILESTONE FIVE MODIFICATIONS: Ziyan Noorani
//  Every part now sets a material before it is drawn, so the Phong lights
//  set up in SceneManager react to each surface the way the real material
//  would: the varnished desk and the glass screens throw highlights, the
//  paper covers and rubber wheel stay flat.
//
//  The darkest solid colors were raised slightly. With lighting on, the
//  shader multiplies the lit result by the surface color, so a surface
//  colored 0.10 can never appear brighter than 0.10 even in full light, and
//  its shaded sides went fully black. The new values still read as black
//  plastic and glaze on the lit faces but keep the shaded faces visible.
//
//  FINAL PROJECT MODIFICATIONS: Ziyan Noorani
//  - Desk texture changed from light wood to black, since my desk is black.
//  - Added RiserShelf and moved the monitor up onto it.
//  - Added DeskMat for the mousepad.
///////////////////////////////////////////////////////////////////////////////

#include "SceneObjects.h"

#include <glm/gtx/transform.hpp>
#include <glm/gtc/constants.hpp>

#include <cmath>
#include <iostream>

namespace
{
	// shader uniform names, matching the names declared in the GLSL files
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UVScaleName = "UVscale";

	/***********************************************************
	 *  Fallback material
	 *
	 *  Used when a part asks for a tag that was never registered.
	 *  Without it the part would silently keep the material of
	 *  whatever was drawn before it. A plain, mid-range, slightly
	 *  matte surface keeps the part lit and visible while the
	 *  console message points at the bad tag.
	 ***********************************************************/
	const ObjectMaterial FALLBACK_MATERIAL =
	{
		0.4f,                          // ambientStrength
		glm::vec3(0.8f, 0.8f, 0.8f),   // ambientColor
		glm::vec3(0.8f, 0.8f, 0.8f),   // diffuseColor
		glm::vec3(0.2f, 0.2f, 0.2f),   // specularColor
		1.0f,                          // shininess
		"fallback"                     // tag
	};
}

// definition of the shared texture registry declared in SceneObject
std::map<std::string, int> SceneObject::s_textureSlots;

// definition of the shared material registry declared in SceneObject
std::map<std::string, ObjectMaterial> SceneObject::s_materials;

///////////////////////////////////////////////////////////////////////////////
//  SceneObject: the abstract base shared by every object below
///////////////////////////////////////////////////////////////////////////////

/***********************************************************
 *  SceneObject()
 *
 *  The constructor for the class
 ***********************************************************/
SceneObject::SceneObject(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
{
	m_pShaderManager = pShaderManager;
	m_pShapeMeshes = pShapeMeshes;
	m_origin = origin;
}

/***********************************************************
 *  ~SceneObject()
 *
 *  The destructor for the class.
 *
 *  Both pointers are cleared rather than deleted. The shader
 *  manager and the mesh library are shared by every object in
 *  the scene and are owned by the SceneManager, so deleting
 *  them here would destroy resources other objects are still
 *  using.
 ***********************************************************/
SceneObject::~SceneObject()
{
	m_pShaderManager = NULL;
	m_pShapeMeshes = NULL;
}

/***********************************************************
 *  SceneObject::GetOrigin()
 ***********************************************************/
glm::vec3 SceneObject::GetOrigin() const
{
	return(m_origin);
}

/***********************************************************
 *  SceneObject::SetOrigin()
 ***********************************************************/
void SceneObject::SetOrigin(glm::vec3 origin)
{
	m_origin = origin;
}

/***********************************************************
 *  SceneObject::SetTransformations()
 *
 *  Builds the model matrix for the next draw command and sends
 *  it to the shader.
 ***********************************************************/
void SceneObject::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 scale = glm::scale(scaleXYZ);
	glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	glm::mat4 translation = glm::translate(positionXYZ);

	// matrices are applied right to left, so the mesh is scaled first,
	// then rotated about its own origin, and only then moved into place
	glm::mat4 modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SceneObject::SetShaderColor()
 *
 *  Sends a solid color to the shader for the next draw command.
 ***********************************************************/
void SceneObject::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SceneObject::LocalToWorld()
 *
 *  Converts an offset measured from this object's own origin
 *  into a world-space position.
 *
 *  A multi-part object such as the mug shares one yaw angle
 *  across all of its parts. Rather than hand-computing a
 *  rotated coordinate for each part, the local offset is run
 *  through the same Y rotation handed to SetTransformations.
 *  Changing the object's yaw then spins the whole object,
 *  handle included, with no other edits required.
 ***********************************************************/
glm::vec3 SceneObject::LocalToWorld(glm::vec3 localOffset, float yawDegrees) const
{
	glm::mat4 yawRotation = glm::rotate(
		glm::radians(yawDegrees),
		glm::vec3(0.0f, 1.0f, 0.0f));

	glm::vec4 rotatedOffset = yawRotation * glm::vec4(localOffset, 1.0f);

	return(m_origin + glm::vec3(rotatedOffset));
}

/***********************************************************
 *  SceneObject::RegisterTextureSlot()
 ***********************************************************/
void SceneObject::RegisterTextureSlot(const std::string& textureTag, int textureSlot)
{
	s_textureSlots[textureTag] = textureSlot;
}

/***********************************************************
 *  SceneObject::ClearTextureSlots()
 ***********************************************************/
void SceneObject::ClearTextureSlots()
{
	s_textureSlots.clear();
}

/***********************************************************
 *  SceneObject::RegisterMaterial()
 ***********************************************************/
void SceneObject::RegisterMaterial(const ObjectMaterial& material)
{
	s_materials[material.tag] = material;
}

/***********************************************************
 *  SceneObject::ClearMaterials()
 ***********************************************************/
void SceneObject::ClearMaterials()
{
	s_materials.clear();
}

/***********************************************************
 *  SceneObject::SetShaderMaterial()
 *
 *  Sends the material registered under materialTag to the
 *  shader's material uniform for the next draw command.
 *
 *  An unknown tag is reported once in the console and drawn
 *  with the fallback material, so a typo in a tag shows up the
 *  first time the scene runs instead of being hidden by the
 *  previous part's material.
 ***********************************************************/
void SceneObject::SetShaderMaterial(const std::string& materialTag)
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	const ObjectMaterial* pMaterial = &FALLBACK_MATERIAL;

	std::map<std::string, ObjectMaterial>::const_iterator entry = s_materials.find(materialTag);

	if (entry != s_materials.end())
	{
		pMaterial = &entry->second;
	}
	else
	{
		// report each missing tag once rather than every frame
		static std::map<std::string, bool> reportedTags;
		if (reportedTags.find(materialTag) == reportedTags.end())
		{
			std::cout << "Material not registered: " << materialTag
				<< " (drawing with fallback material)" << std::endl;
			reportedTags[materialTag] = true;
		}
	}

	m_pShaderManager->setVec3Value("material.ambientColor", pMaterial->ambientColor);
	m_pShaderManager->setFloatValue("material.ambientStrength", pMaterial->ambientStrength);
	m_pShaderManager->setVec3Value("material.diffuseColor", pMaterial->diffuseColor);
	m_pShaderManager->setVec3Value("material.specularColor", pMaterial->specularColor);
	m_pShaderManager->setFloatValue("material.shininess", pMaterial->shininess);
}

/***********************************************************
 *  SceneObject::SetShaderTexture()
 *
 *  Sends the texture registered under textureTag to the
 *  shader for the next draw command.
 *
 *  If the tag was never registered, usually because the image
 *  file failed to load, the part is drawn solid magenta
 *  instead. Magenta is the conventional missing-texture color:
 *  it cannot be mistaken for a real surface, so a bad file path
 *  shows up the moment the scene runs instead of silently
 *  sampling whatever texture sits in slot 0.
 ***********************************************************/
void SceneObject::SetShaderTexture(const std::string& textureTag)
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	std::map<std::string, int>::const_iterator entry = s_textureSlots.find(textureTag);

	if (entry == s_textureSlots.end())
	{
		SetShaderColor(1.0f, 0.0f, 1.0f, 1.0f);
		return;
	}

	m_pShaderManager->setIntValue(g_UseTextureName, true);
	m_pShaderManager->setSampler2DValue(g_TextureValueName, entry->second);

	// the UV scale uniform keeps its value between draw calls, so it is
	// reset here and each part sets its own tiling afterwards
	SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  SceneObject::SetTextureUVScale()
 ***********************************************************/
void SceneObject::SetTextureUVScale(float uScale, float vScale)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value(g_UVScaleName, glm::vec2(uScale, vScale));
	}
}

/***********************************************************
 *  SceneObject::DrawTiledCylinder()
 *
 *  The cylinder mesh maps the texture once around the side
 *  and once across each end cap. Stretched over a tall, thin
 *  post that single copy is smeared vertically; stretched over
 *  a wide, flat base it is smeared around the rim. Tiling by
 *  real size fixes both.
 *
 *  Side: U runs around the circumference, V runs up the
 *  height. U is rounded to a whole number because the texture
 *  has to finish a complete repeat where the side wraps back
 *  to its starting edge. A fractional count leaves a visible
 *  seam running down the back of the cylinder.
 *
 *  Caps: the cap's UVs span the full diameter in both
 *  directions, so both axes get the same repeat count and the
 *  texture stays square.
 ***********************************************************/
void SceneObject::DrawTiledCylinder(float radius, float height, float tileSize)
{
	float circumference = 2.0f * glm::pi<float>() * radius;

	float sideRepeatsU = std::round(circumference / tileSize);
	float sideRepeatsV = height / tileSize;

	// very thin parts can round down to zero, which would sample a
	// single texel and turn the part one flat color
	if (sideRepeatsU < 1.0f)
	{
		sideRepeatsU = 1.0f;
	}

	SetTextureUVScale(sideRepeatsU, sideRepeatsV);
	m_pShapeMeshes->DrawCylinderMesh(false, false, true);

	float capRepeats = (2.0f * radius) / tileSize;

	SetTextureUVScale(capRepeats, capRepeats);
	m_pShapeMeshes->DrawCylinderMesh(true, true, false);
}

///////////////////////////////////////////////////////////////////////////////
//  DeskSurface
///////////////////////////////////////////////////////////////////////////////

const float DeskSurface::SURFACE_HALF_WIDTH = 10.0f;
const float DeskSurface::SURFACE_HALF_DEPTH = 8.0f;

// 4 units is about 6 inches, close to the plank width of a real desktop
const float DeskSurface::WOOD_TILE_SIZE = 6.0f;

DeskSurface::DeskSurface(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  DeskSurface::Draw()
 *
 *  Draws the flat desktop that every other object rests on.
 *
 *  The plane needs no rotation because the mesh is already
 *  generated in the XZ plane at y = 0.
 *
 *  The desk is deliberately left as a plane with no thickness.
 *  A solid slab would give it a visible edge in perspective
 *  view, but it would also show as a band across the bottom of
 *  the orthographic view, where a zero-thickness plane seen
 *  exactly edge on correctly disappears instead.
 ***********************************************************/
void DeskSurface::Draw()
{
	// scale: stretch the unit plane out to desk proportions
	// rotate: none needed, the mesh already lies flat
	// translate: leave it on this object's origin
	SetTransformations(
		glm::vec3(SURFACE_HALF_WIDTH, 1.0f, SURFACE_HALF_DEPTH),
		0.0f,
		0.0f,
		0.0f,
		m_origin);

	// Complex technique: tiling. One image stretched across a 20 x 16
	// desk blows the grain up and makes it wider than it is deep.
	// Repeating a seamless tile by the desk's real size keeps every tile
	// square. The black texture has longer streaks than the old wood, so
	// the tile is 6 units instead of 4.
	SetShaderTexture("desk_black");
	SetTextureUVScale(
		(SURFACE_HALF_WIDTH * 2.0f) / WOOD_TILE_SIZE,
		(SURFACE_HALF_DEPTH * 2.0f) / WOOD_TILE_SIZE);

	// varnished wood: mostly diffuse, with enough specular to show a soft
	// sheen where the lights reflect off the desktop toward the camera
	SetShaderMaterial("desk_wood");

	m_pShapeMeshes->DrawPlaneMesh();
}

///////////////////////////////////////////////////////////////////////////////
//  RiserShelf
///////////////////////////////////////////////////////////////////////////////

const float RiserShelf::TOP_HEIGHT = 2.00f;
const glm::vec3 RiserShelf::SHELF_SCALE = glm::vec3(18.0f, 0.40f, 4.0f);
const glm::vec3 RiserShelf::LEG_SCALE = glm::vec3(0.40f, 1.60f, 0.40f);
const float RiserShelf::LEG_INSET = 0.50f;

RiserShelf::RiserShelf(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  RiserShelf::Draw()
 *
 *  The shelf top is lowered by half its thickness so its top
 *  surface lands exactly at TOP_HEIGHT. The legs fill the space
 *  between the desk and the bottom of the shelf.
 ***********************************************************/
void RiserShelf::Draw()
{
	SetTransformations(
		SHELF_SCALE,
		0.0f,
		0.0f,
		0.0f,
		m_origin + glm::vec3(0.0f, TOP_HEIGHT - (SHELF_SCALE.y / 2.0f), 0.0f));

	// same black laminate as the desk
	SetShaderColor(0.13f, 0.13f, 0.14f, 1.0f);
	SetShaderMaterial("matte_plastic");

	m_pShapeMeshes->DrawBoxMesh();

	DrawLeg(1.0f, 1.0f);
	DrawLeg(-1.0f, 1.0f);
	DrawLeg(1.0f, -1.0f);
	DrawLeg(-1.0f, -1.0f);
}

/***********************************************************
 *  RiserShelf::DrawLeg()
 *
 *  All four legs are the same box, so one method draws any of
 *  them. The signs pick the corner.
 ***********************************************************/
void RiserShelf::DrawLeg(float xSign, float zSign)
{
	float legX = xSign * ((SHELF_SCALE.x / 2.0f) - LEG_INSET);
	float legZ = zSign * ((SHELF_SCALE.z / 2.0f) - LEG_INSET);

	SetTransformations(
		LEG_SCALE,
		0.0f,
		0.0f,
		0.0f,
		m_origin + glm::vec3(legX, LEG_SCALE.y / 2.0f, legZ));

	SetShaderColor(0.11f, 0.11f, 0.12f, 1.0f);
	SetShaderMaterial("matte_plastic");

	m_pShapeMeshes->DrawBoxMesh();
}

///////////////////////////////////////////////////////////////////////////////
//  DeskMat
///////////////////////////////////////////////////////////////////////////////

const float DeskMat::HALF_WIDTH = 9.0f;
const float DeskMat::HALF_DEPTH = 3.5f;
const float DeskMat::TILE_SIZE = 9.0f;

DeskMat::DeskMat(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  DeskMat::Draw()
 *
 *  A plane just above the desk. It sits 0.02 units up because
 *  two surfaces at the same height flicker (z-fighting).
 *
 *  The texture is tiled by size like the desk so the lines are
 *  not stretched sideways across the long mat.
 *
 *  TODO: the real mat has a stitched edge. It could be added as
 *  four thin boxes around the border.
 ***********************************************************/
void DeskMat::Draw()
{
	SetTransformations(
		glm::vec3(HALF_WIDTH, 1.0f, HALF_DEPTH),
		0.0f,
		0.0f,
		0.0f,
		m_origin);

	SetShaderTexture("mousepad");
	SetTextureUVScale(
		(HALF_WIDTH * 2.0f) / TILE_SIZE,
		(HALF_DEPTH * 2.0f) / TILE_SIZE);

	SetShaderMaterial("mat_cloth");

	m_pShapeMeshes->DrawPlaneMesh();
}

///////////////////////////////////////////////////////////////////////////////
//  Monitor
///////////////////////////////////////////////////////////////////////////////

const float Monitor::YAW_DEGREES = 0.0f;

const glm::vec3 Monitor::BASE_SCALE = glm::vec3(4.50f, 0.30f, 2.60f);
const glm::vec3 Monitor::NECK_SCALE = glm::vec3(1.20f, 2.80f, 0.70f);
const glm::vec3 Monitor::BEZEL_SCALE = glm::vec3(12.00f, 7.20f, 0.45f);
const glm::vec3 Monitor::SCREEN_SCALE = glm::vec3(11.40f, 6.60f, 0.06f);

// lowered from 2.8 when the monitor moved up onto the riser, so the
// whole scene still fits in the starting camera view
const float Monitor::SCREEN_BOTTOM_HEIGHT = 1.60f;
const float Monitor::PANEL_DEPTH_OFFSET = -0.30f;

Monitor::Monitor(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  Monitor::Draw()
 *
 *  Draws the display at the back of the desk from four boxes:
 *  a base, a neck, the bezel, and the screen face.
 *
 *  Drawn from the bottom up so the code reads in the same
 *  order the object is assembled.
 ***********************************************************/
void Monitor::Draw()
{
	// ----------------------------------------------------------------
	// Base
	// Raised by half its own thickness so it rests on the desk rather
	// than sinking half way through it.
	// ----------------------------------------------------------------
	SetTransformations(
		BASE_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, BASE_SCALE.y / 2.0f, 0.0f), YAW_DEGREES));

	SetShaderColor(0.22f, 0.22f, 0.24f, 1.0f);
	SetShaderMaterial("matte_plastic");

	m_pShapeMeshes->DrawBoxMesh();

	// ----------------------------------------------------------------
	// Neck
	// Set slightly behind the base center so the panel sits over the
	// back of the stand instead of overhanging its front edge.
	// ----------------------------------------------------------------
	SetTransformations(
		NECK_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, NECK_SCALE.y / 2.0f, PANEL_DEPTH_OFFSET), YAW_DEGREES));

	SetShaderColor(0.24f, 0.24f, 0.26f, 1.0f);
	SetShaderMaterial("matte_plastic");

	m_pShapeMeshes->DrawBoxMesh();

	// ----------------------------------------------------------------
	// Bezel
	// The outer shell of the panel. Its center sits half a panel height
	// above the point where the panel starts.
	// ----------------------------------------------------------------
	float bezelCenterHeight = SCREEN_BOTTOM_HEIGHT + (BEZEL_SCALE.y / 2.0f);

	SetTransformations(
		BEZEL_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, bezelCenterHeight, PANEL_DEPTH_OFFSET), YAW_DEGREES));

	SetShaderColor(0.17f, 0.17f, 0.18f, 1.0f);
	SetShaderMaterial("matte_plastic");

	m_pShapeMeshes->DrawBoxMesh();

	// ----------------------------------------------------------------
	// Screen face
	// A thin panel pushed forward out of the bezel by slightly more than
	// half the bezel depth. Pushing it forward rather than centering it
	// avoids z-fighting, where two surfaces at the same depth flicker
	// against each other as the camera moves.
	// ----------------------------------------------------------------
	float screenForwardOffset = PANEL_DEPTH_OFFSET + (BEZEL_SCALE.z / 2.0f) + 0.02f;

	SetTransformations(
		SCREEN_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, bezelCenterHeight, screenForwardOffset), YAW_DEGREES));

	// a dark, slightly blue gray, the color of a powered screen showing
	// a dark desktop rather than pure black glass
	SetShaderColor(0.20f, 0.26f, 0.34f, 1.0f);

	// glass: a tight, bright highlight, which is what makes the panel read
	// as a screen rather than one more matte box
	SetShaderMaterial("screen_glass");

	m_pShapeMeshes->DrawBoxMesh();
}

///////////////////////////////////////////////////////////////////////////////
//  CoffeeMug
///////////////////////////////////////////////////////////////////////////////

const float CoffeeMug::YAW_DEGREES = -25.0f;

const float CoffeeMug::BODY_RADIUS = 1.00f;
const float CoffeeMug::BODY_HEIGHT = 1.90f;

const float CoffeeMug::BAND_RADIUS = 1.05f;
const float CoffeeMug::BAND_HEIGHT = 0.10f;

const float CoffeeMug::COFFEE_RADIUS = 0.90f;
const float CoffeeMug::COFFEE_HEIGHT = 0.03f;

const float CoffeeMug::HANDLE_RING_RADIUS = 0.52f;
const float CoffeeMug::HANDLE_TUBE_DEPTH = 0.38f;
const glm::vec3 CoffeeMug::HANDLE_OFFSET = glm::vec3(1.05f, 0.95f, 0.0f);

CoffeeMug::CoffeeMug(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  CoffeeMug::Draw()
 *
 *  Draws the complex object from Milestone Two: the black
 *  coffee mug from the 2D desk reference image.
 *
 *  The mug is assembled from five transformed primitives and
 *  drawn from the bottom up, one part per method, so that a
 *  change to the handle does not require reading the code for
 *  the body.
 ***********************************************************/
void CoffeeMug::Draw()
{
	DrawFootBand();
	DrawBody();
	DrawLipBand();
	DrawCoffeeSurface();
	DrawHandle();
}

/***********************************************************
 *  CoffeeMug::DrawFootBand()
 *
 *  A slightly wider disc at the base gives the mug the stepped
 *  ceramic profile visible along the bottom edge in the photo.
 ***********************************************************/
void CoffeeMug::DrawFootBand()
{
	SetTransformations(
		glm::vec3(BAND_RADIUS, BAND_HEIGHT, BAND_RADIUS),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, 0.0f, 0.0f), YAW_DEGREES));

	// slightly lifted from pure black so the band edge stays readable
	SetShaderColor(0.24f, 0.24f, 0.25f, 1.0f);
	SetShaderMaterial("ceramic_glaze");

	m_pShapeMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  CoffeeMug::DrawBody()
 *
 *  The cylinder mesh is generated with its base at y = 0 and a
 *  height of 1, so the Y scale sets the finished mug height
 *  directly and the body can sit at y = 0 with no offset.
 ***********************************************************/
void CoffeeMug::DrawBody()
{
	SetTransformations(
		glm::vec3(BODY_RADIUS, BODY_HEIGHT, BODY_RADIUS),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, 0.0f, 0.0f), YAW_DEGREES));

	// the near-black glaze of the mug in the reference image
	SetShaderColor(0.17f, 0.17f, 0.18f, 1.0f);
	SetShaderMaterial("ceramic_glaze");

	m_pShapeMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  CoffeeMug::DrawLipBand()
 *
 *  Positioned so its top edge finishes flush with the top of
 *  the body rather than floating above it.
 ***********************************************************/
void CoffeeMug::DrawLipBand()
{
	SetTransformations(
		glm::vec3(BAND_RADIUS, BAND_HEIGHT, BAND_RADIUS),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, BODY_HEIGHT - BAND_HEIGHT, 0.0f), YAW_DEGREES));

	SetShaderColor(0.24f, 0.24f, 0.25f, 1.0f);
	SetShaderMaterial("ceramic_glaze");

	m_pShapeMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  CoffeeMug::DrawCoffeeSurface()
 *
 *  A thin disc set just above the body's top cap. It is
 *  narrower than the body so the ceramic wall still shows
 *  around it, which is what sells the mug as hollow without
 *  modeling an interior.
 ***********************************************************/
void CoffeeMug::DrawCoffeeSurface()
{
	SetTransformations(
		glm::vec3(COFFEE_RADIUS, COFFEE_HEIGHT, COFFEE_RADIUS),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, BODY_HEIGHT - 0.01f, 0.0f), YAW_DEGREES));

	// dark roast brown
	SetShaderColor(0.24f, 0.13f, 0.06f, 1.0f);

	// liquid surface: glossy, so it catches the overhead light
	SetShaderMaterial("coffee");

	m_pShapeMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  CoffeeMug::DrawHandle()
 *
 *  The torus mesh is generated in the XY plane, which is
 *  already the correct plane for a handle on the mug's right
 *  side, so the only rotation it needs is the shared mug yaw.
 *
 *  The Z scale is smaller than the X and Y scale, flattening
 *  the tube front to back the way a real ceramic handle is
 *  flattened. The X offset places the ring center on the body
 *  wall so the inner half of the ring is buried inside the mug
 *  and the joint reads as solid.
 ***********************************************************/
void CoffeeMug::DrawHandle()
{
	SetTransformations(
		glm::vec3(HANDLE_RING_RADIUS, HANDLE_RING_RADIUS, HANDLE_TUBE_DEPTH),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(HANDLE_OFFSET, YAW_DEGREES));

	SetShaderColor(0.21f, 0.21f, 0.22f, 1.0f);
	SetShaderMaterial("ceramic_glaze");

	m_pShapeMeshes->DrawTorusMesh();
}

///////////////////////////////////////////////////////////////////////////////
//  NotebookStack
///////////////////////////////////////////////////////////////////////////////

const glm::vec3 NotebookStack::LOWER_SCALE = glm::vec3(2.30f, 0.18f, 1.65f);
const glm::vec3 NotebookStack::UPPER_SCALE = glm::vec3(2.05f, 0.16f, 1.50f);
const float NotebookStack::LOWER_YAW = 8.0f;
const float NotebookStack::UPPER_YAW = -6.0f;

NotebookStack::NotebookStack(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  NotebookStack::Draw()
 *
 *  Draws the stacked notebooks that sit beside the mug in the
 *  2D reference image. They establish the mug's scale against
 *  the rest of the desk.
 *
 *  Each cover is turned a few degrees off axis, the way a stack
 *  of books never ends up perfectly square on a desk, and the
 *  two are turned opposite ways so they stay visually distinct
 *  from the camera.
 ***********************************************************/
void NotebookStack::Draw()
{
	// lower notebook, resting directly on the desk, navy cover
	DrawNotebook(
		LOWER_SCALE,
		LOWER_YAW,
		0.0f,
		glm::vec3(0.0f, 0.0f, 0.0f),
		0.16f, 0.24f, 0.42f);

	// upper notebook, resting on the lower one and nudged over, rust cover
	DrawNotebook(
		UPPER_SCALE,
		UPPER_YAW,
		LOWER_SCALE.y,
		glm::vec3(0.08f, 0.0f, -0.06f),
		0.60f, 0.30f, 0.20f);
}

/***********************************************************
 *  NotebookStack::DrawNotebook()
 *
 *  Draws one notebook resting on the surface below it.
 *
 *  The box mesh is centered on its own origin, so the notebook
 *  is raised by half its own thickness above the resting height
 *  to keep it sitting on that surface instead of sinking
 *  through it. Passing the resting height in rather than the
 *  center height means adding a third notebook only requires
 *  summing the thicknesses below it.
 ***********************************************************/
void NotebookStack::DrawNotebook(
	glm::vec3 scale,
	float yawDegrees,
	float restingHeight,
	glm::vec3 offsetFromOrigin,
	float red,
	float green,
	float blue)
{
	glm::vec3 position = m_origin + offsetFromOrigin;
	position.y = restingHeight + (scale.y / 2.0f);

	SetTransformations(
		scale,
		0.0f,
		yawDegrees,
		0.0f,
		position);

	SetShaderColor(red, green, blue, 1.0f);
	SetShaderMaterial("paper_cover");

	m_pShapeMeshes->DrawBoxMesh();
}

///////////////////////////////////////////////////////////////////////////////
//  PencilCup
///////////////////////////////////////////////////////////////////////////////

const float PencilCup::YAW_DEGREES = 12.0f;
const glm::vec3 PencilCup::CUP_SCALE = glm::vec3(1.80f, 2.40f, 1.80f);

const float PencilCup::PENCIL_RADIUS = 0.09f;
const float PencilCup::PENCIL_LENGTH = 3.60f;
const float PencilCup::PENCIL_BASE_HEIGHT = 1.00f;

PencilCup::PencilCup(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  PencilCup::Draw()
 *
 *  Draws the square pencil cup and the three pencils standing
 *  in it. The cup is drawn first so the pencils are added on
 *  top of a surface that already exists in the depth buffer.
 ***********************************************************/
void PencilCup::Draw()
{
	DrawCup();

	// three pencils leaning different ways, so the group reads as loose
	// pencils in a cup rather than a bundle glued together
	DrawPencil(glm::vec3(-0.35f, PENCIL_BASE_HEIGHT, -0.25f), 6.0f, 9.0f, 0.92f, 0.72f, 0.15f);
	DrawPencil(glm::vec3(0.30f, PENCIL_BASE_HEIGHT, 0.15f), -7.0f, -5.0f, 0.85f, 0.35f, 0.25f);
	DrawPencil(glm::vec3(0.05f, PENCIL_BASE_HEIGHT, -0.30f), 3.0f, -8.0f, 0.25f, 0.45f, 0.70f);
}

/***********************************************************
 *  PencilCup::DrawCup()
 *
 *  The square cup body. Raised by half its own height because
 *  the box mesh is centered on its origin.
 ***********************************************************/
void PencilCup::DrawCup()
{
	SetTransformations(
		CUP_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, CUP_SCALE.y / 2.0f, 0.0f), YAW_DEGREES));

	// brushed dark gray metal
	SetShaderColor(0.30f, 0.32f, 0.35f, 1.0f);
	SetShaderMaterial("brushed_metal");

	m_pShapeMeshes->DrawBoxMesh();
}

/***********************************************************
 *  PencilCup::DrawPencil()
 *
 *  Draws one pencil as a thin cylinder.
 *
 *  The cylinder mesh starts at y = 0, so the X and Z rotations
 *  pivot the pencil about its own lower end. That keeps the
 *  bottom of every pencil planted inside the cup while the tops
 *  fan out, which is what a tilt applied to a centered mesh
 *  would not do.
 ***********************************************************/
void PencilCup::DrawPencil(
	glm::vec3 offsetFromOrigin,
	float tiltXDegrees,
	float tiltZDegrees,
	float red,
	float green,
	float blue)
{
	SetTransformations(
		glm::vec3(PENCIL_RADIUS, PENCIL_LENGTH, PENCIL_RADIUS),
		tiltXDegrees,
		YAW_DEGREES,
		tiltZDegrees,
		LocalToWorld(offsetFromOrigin, YAW_DEGREES));

	SetShaderColor(red, green, blue, 1.0f);
	SetShaderMaterial("painted_wood");

	m_pShapeMeshes->DrawCylinderMesh();
}

///////////////////////////////////////////////////////////////////////////////
//  Keyboard
///////////////////////////////////////////////////////////////////////////////

const float Keyboard::YAW_DEGREES = 0.0f;

const glm::vec3 Keyboard::CASE_SCALE = glm::vec3(9.00f, 0.35f, 3.20f);
const glm::vec3 Keyboard::PLATE_SCALE = glm::vec3(8.40f, 0.16f, 2.75f);
const glm::vec3 Keyboard::KEY_ROW_SCALE = glm::vec3(8.00f, 0.16f, 0.40f);

const int Keyboard::KEY_ROW_COUNT = 5;
const float Keyboard::KEY_ROW_SPACING = 0.52f;

Keyboard::Keyboard(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  Keyboard::Draw()
 *
 *  Drawn bottom up: the case, the plate that sits inside it,
 *  then the key rows on top of the plate.
 ***********************************************************/
void Keyboard::Draw()
{
	DrawCase();
	DrawPlate();
	DrawKeyRows();
}

/***********************************************************
 *  Keyboard::DrawCase()
 *
 *  The outer shell. Raised by half its own height because the
 *  box mesh is centered on its origin.
 ***********************************************************/
void Keyboard::DrawCase()
{
	SetTransformations(
		CASE_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, CASE_SCALE.y / 2.0f, 0.0f), YAW_DEGREES));

	SetShaderColor(0.19f, 0.19f, 0.21f, 1.0f);
	SetShaderMaterial("matte_plastic");

	m_pShapeMeshes->DrawBoxMesh();
}

/***********************************************************
 *  Keyboard::DrawPlate()
 *
 *  The mounting plate, inset from the case on every side. It
 *  is deliberately lighter than both the case and the keys,
 *  because it is the gap between the key rows that makes the
 *  rows read as separate keys rather than one solid slab.
 ***********************************************************/
void Keyboard::DrawPlate()
{
	float plateCenterHeight = CASE_SCALE.y + (PLATE_SCALE.y / 2.0f);

	SetTransformations(
		PLATE_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, plateCenterHeight, 0.0f), YAW_DEGREES));

	SetShaderColor(0.32f, 0.33f, 0.36f, 1.0f);

	// mechanical keyboard plates are usually steel or aluminum, and the
	// metal highlight between the rows helps separate them
	SetShaderMaterial("brushed_metal");

	m_pShapeMeshes->DrawBoxMesh();
}

/***********************************************************
 *  Keyboard::DrawKeyRows()
 *
 *  Five strips laid front to back across the plate.
 *
 *  The rows are centered on the plate by offsetting each one
 *  from the middle of the row count, so changing KEY_ROW_COUNT
 *  keeps the block centered instead of pushing it off the back
 *  edge of the keyboard.
 ***********************************************************/
void Keyboard::DrawKeyRows()
{
	float rowCenterHeight =
		CASE_SCALE.y + PLATE_SCALE.y + (KEY_ROW_SCALE.y / 2.0f);

	float firstRowOffset = -((KEY_ROW_COUNT - 1) * KEY_ROW_SPACING) / 2.0f;

	for (int row = 0; row < KEY_ROW_COUNT; row++)
	{
		float rowDepthOffset = firstRowOffset + (row * KEY_ROW_SPACING);

		SetTransformations(
			KEY_ROW_SCALE,
			0.0f,
			YAW_DEGREES,
			0.0f,
			LocalToWorld(
				glm::vec3(0.0f, rowCenterHeight, rowDepthOffset),
				YAW_DEGREES));

		SetShaderColor(0.16f, 0.16f, 0.18f, 1.0f);
		SetShaderMaterial("matte_plastic");

		m_pShapeMeshes->DrawBoxMesh();
	}
}

///////////////////////////////////////////////////////////////////////////////
//  Microphone
///////////////////////////////////////////////////////////////////////////////

const float Microphone::YAW_DEGREES = 0.0f;

const float Microphone::BASE_RADIUS = 0.80f;
const float Microphone::BASE_HEIGHT = 0.25f;
const float Microphone::POST_RADIUS = 0.13f;
const float Microphone::POST_HEIGHT = 1.40f;

const float Microphone::BODY_RADIUS = 0.44f;
const float Microphone::BODY_HEIGHT = 2.60f;
const float Microphone::CAP_RADIUS = 0.48f;
const float Microphone::CAP_HEIGHT = 0.22f;

const float Microphone::MOUNT_RING_RADIUS = 0.72f;
const float Microphone::MOUNT_RING_THICKNESS = 0.17f;

const float Microphone::METAL_TILE_SIZE = 1.00f;
const float Microphone::PLASTIC_TILE_SIZE = 1.00f;
// 2.6-unit barrel / 0.45 = about 6 repeats around and 6 up the barrel
const float Microphone::MESH_TILE_SIZE = 0.45f;

Microphone::Microphone(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  Microphone::Draw()
 *
 *  The shock mount ring is drawn last so it is laid over the
 *  body rather than the body being laid over it.
 ***********************************************************/
void Microphone::Draw()
{
	DrawStand();
	DrawBody();
	DrawShockMount();
}

/***********************************************************
 *  Microphone::DrawStand()
 *
 *  The weighted base and the post rising out of it. Both use
 *  the cylinder mesh, which starts at y = 0, so each part sits
 *  directly on the height where the part below it ends.
 ***********************************************************/
void Microphone::DrawStand()
{
	// weighted base
	SetTransformations(
		glm::vec3(BASE_RADIUS, BASE_HEIGHT, BASE_RADIUS),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, 0.0f, 0.0f), YAW_DEGREES));

	SetShaderTexture("stand_metal");
	SetShaderMaterial("brushed_metal");
	DrawTiledCylinder(BASE_RADIUS, BASE_HEIGHT, METAL_TILE_SIZE);

	// post: same texture and same tile size as the base, so the brushed
	// grain carries straight through the joint instead of changing scale
	SetTransformations(
		glm::vec3(POST_RADIUS, POST_HEIGHT, POST_RADIUS),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, BASE_HEIGHT, 0.0f), YAW_DEGREES));

	SetShaderTexture("stand_metal");
	SetShaderMaterial("brushed_metal");
	DrawTiledCylinder(POST_RADIUS, POST_HEIGHT, METAL_TILE_SIZE);
}

/***********************************************************
 *  Microphone::DrawBody()
 *
 *  The red mesh barrel with a darker cap at each end. The caps
 *  are slightly wider than the barrel, which is what gives the
 *  microphone its stepped profile instead of reading as one
 *  plain tube.
 ***********************************************************/
void Microphone::DrawBody()
{
	float bodyBottom = BASE_HEIGHT + POST_HEIGHT;

	// lower cap
	SetTransformations(
		glm::vec3(CAP_RADIUS, CAP_HEIGHT, CAP_RADIUS),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, bodyBottom, 0.0f), YAW_DEGREES));

	SetShaderTexture("mic_plastic");
	SetShaderMaterial("mic_plastic");
	DrawTiledCylinder(CAP_RADIUS, CAP_HEIGHT, PLASTIC_TILE_SIZE);

	// red mesh barrel
	// Complex technique: tiling on a curved surface. One mesh image
	// wrapped once around the barrel turns the holes into large ovals.
	// Tiling it about six times each way keeps the holes small and round,
	// and the whole-number count around the barrel hides the wrap seam.
	SetTransformations(
		glm::vec3(BODY_RADIUS, BODY_HEIGHT, BODY_RADIUS),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, bodyBottom + CAP_HEIGHT, 0.0f), YAW_DEGREES));

	SetShaderTexture("mic_mesh");
	SetShaderMaterial("mic_mesh");
	DrawTiledCylinder(BODY_RADIUS, BODY_HEIGHT, MESH_TILE_SIZE);

	// upper cap
	SetTransformations(
		glm::vec3(CAP_RADIUS, CAP_HEIGHT, CAP_RADIUS),
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(
			glm::vec3(0.0f, bodyBottom + CAP_HEIGHT + BODY_HEIGHT, 0.0f),
			YAW_DEGREES));

	SetShaderTexture("mic_plastic");
	SetShaderMaterial("mic_plastic");
	DrawTiledCylinder(CAP_RADIUS, CAP_HEIGHT, PLASTIC_TILE_SIZE);
}

/***********************************************************
 *  Microphone::DrawShockMount()
 *
 *  The ring that cradles the microphone at its midpoint.
 *
 *  The torus mesh is generated in the XY plane, standing
 *  upright like a wheel. A ring around a vertical barrel has to
 *  lie flat instead, so it is rotated 90 degrees about X. After
 *  that rotation the mesh's Z scale controls the ring's
 *  vertical thickness, which is why the thickness value is
 *  passed as the Z component.
 ***********************************************************/
void Microphone::DrawShockMount()
{
	float ringHeight = BASE_HEIGHT + POST_HEIGHT + CAP_HEIGHT + (BODY_HEIGHT / 2.0f);

	SetTransformations(
		glm::vec3(MOUNT_RING_RADIUS, MOUNT_RING_RADIUS, MOUNT_RING_THICKNESS),
		90.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, ringHeight, 0.0f), YAW_DEGREES));

	// same metal as the stand, since the mount is part of the stand
	// hardware. U runs around the ring, so it gets a whole-number repeat
	// count for the same seam reason as the cylinders.
	SetShaderTexture("stand_metal");
	SetShaderMaterial("brushed_metal");

	float ringCircumference = 2.0f * glm::pi<float>() * MOUNT_RING_RADIUS;
	SetTextureUVScale(std::round(ringCircumference / METAL_TILE_SIZE), 1.0f);

	m_pShapeMeshes->DrawTorusMesh();
}

///////////////////////////////////////////////////////////////////////////////
//  Mouse
///////////////////////////////////////////////////////////////////////////////

const float Mouse::YAW_DEGREES = -6.0f;
const glm::vec3 Mouse::SHELL_SCALE = glm::vec3(0.55f, 0.40f, 0.85f);
const float Mouse::WHEEL_RADIUS = 0.07f;
const float Mouse::WHEEL_WIDTH = 0.14f;

Mouse::Mouse(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  Mouse::Draw()
 *
 *  The shell is a sphere scaled unevenly on all three axes:
 *  narrow across, low in height, and long front to back. The
 *  sphere mesh is centered on its own origin, so lifting it by
 *  its Y scale puts the bottom of the dome exactly on the desk.
 *
 *  The scroll wheel is a cylinder turned on its side. Rotating
 *  90 degrees about Z lays the cylinder's axis along X, which
 *  is the axis a scroll wheel actually turns on.
 ***********************************************************/
void Mouse::Draw()
{
	// shell
	SetTransformations(
		SHELL_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, SHELL_SCALE.y, 0.0f), YAW_DEGREES));

	SetShaderColor(0.18f, 0.18f, 0.19f, 1.0f);

	// glossy shell: the curved highlight is what shows the dome shape
	SetShaderMaterial("gloss_plastic");

	m_pShapeMeshes->DrawSphereMesh();

	// scroll wheel, set into the front half of the shell. The X offset is
	// half the wheel width because the cylinder grows from its own base
	// rather than from its center.
	SetTransformations(
		glm::vec3(WHEEL_RADIUS, WHEEL_WIDTH, WHEEL_RADIUS),
		0.0f,
		YAW_DEGREES,
		90.0f,
		LocalToWorld(
			glm::vec3(WHEEL_WIDTH / 2.0f, SHELL_SCALE.y + 0.22f, 0.34f),
			YAW_DEGREES));

	SetShaderColor(0.38f, 0.38f, 0.42f, 1.0f);
	SetShaderMaterial("matte_plastic");

	m_pShapeMeshes->DrawCylinderMesh();
}

///////////////////////////////////////////////////////////////////////////////
//  PhoneStand
///////////////////////////////////////////////////////////////////////////////

const float PhoneStand::YAW_DEGREES = 14.0f;
const float PhoneStand::LEAN_DEGREES = -20.0f;

const glm::vec3 PhoneStand::BASE_SCALE = glm::vec3(1.70f, 0.14f, 1.30f);
const glm::vec3 PhoneStand::LIP_SCALE = glm::vec3(1.70f, 0.32f, 0.16f);
const glm::vec3 PhoneStand::ARM_SCALE = glm::vec3(0.45f, 1.90f, 0.14f);
const glm::vec3 PhoneStand::PHONE_SCALE = glm::vec3(1.55f, 2.70f, 0.11f);
const glm::vec3 PhoneStand::SCREEN_SCALE = glm::vec3(1.35f, 2.40f, 0.04f);

PhoneStand::PhoneStand(
	ShaderManager* pShaderManager,
	ShapeMeshes* pShapeMeshes,
	glm::vec3 origin)
	: SceneObject(pShaderManager, pShapeMeshes, origin)
{
}

/***********************************************************
 *  PhoneStand::LeaningCenter()
 *
 *  Returns the center an object needs so that it leans back by
 *  LEAN_DEGREES while its lower edge stays planted.
 *
 *  Rotation happens about the box's own center, so simply
 *  tilting a box that was positioned upright would swing its
 *  bottom edge out through the front of the stand. Tilting the
 *  center by the same angle keeps the bottom edge in place and
 *  lets the top do the moving, which is how a phone actually
 *  rests in a stand.
 ***********************************************************/
glm::vec3 PhoneStand::LeaningCenter(float objectHeight, float restingHeight) const
{
	float leanRadians = glm::radians(LEAN_DEGREES);
	float halfHeight = objectHeight / 2.0f;

	return(glm::vec3(
		0.0f,
		restingHeight + (halfHeight * std::cos(leanRadians)),
		halfHeight * std::sin(leanRadians)));
}

/***********************************************************
 *  PhoneStand::Draw()
 ***********************************************************/
void PhoneStand::Draw()
{
	DrawStand();
	DrawPhone();
}

/***********************************************************
 *  PhoneStand::DrawStand()
 *
 *  The flat base, the lip along its front edge that stops the
 *  phone sliding off, and the arm behind that holds the lean.
 ***********************************************************/
void PhoneStand::DrawStand()
{
	// base
	SetTransformations(
		BASE_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(glm::vec3(0.0f, BASE_SCALE.y / 2.0f, 0.0f), YAW_DEGREES));

	SetShaderColor(0.90f, 0.90f, 0.92f, 1.0f);
	SetShaderMaterial("white_plastic");

	m_pShapeMeshes->DrawBoxMesh();

	// front lip
	SetTransformations(
		LIP_SCALE,
		0.0f,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(
			glm::vec3(0.0f, LIP_SCALE.y / 2.0f, (BASE_SCALE.z / 2.0f) - (LIP_SCALE.z / 2.0f)),
			YAW_DEGREES));

	SetShaderColor(0.88f, 0.88f, 0.90f, 1.0f);
	SetShaderMaterial("white_plastic");

	m_pShapeMeshes->DrawBoxMesh();

	// supporting arm, set behind the phone so it is not drawn through it
	glm::vec3 armCenter = LeaningCenter(ARM_SCALE.y, BASE_SCALE.y);
	armCenter.z -= 0.16f;

	SetTransformations(
		ARM_SCALE,
		LEAN_DEGREES,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(armCenter, YAW_DEGREES));

	SetShaderColor(0.86f, 0.86f, 0.88f, 1.0f);
	SetShaderMaterial("white_plastic");

	m_pShapeMeshes->DrawBoxMesh();
}

/***********************************************************
 *  PhoneStand::DrawPhone()
 *
 *  The phone body and its screen, both sharing the stand's
 *  lean.
 *
 *  The screen is pushed out along the phone's own face
 *  direction rather than straight along Z. A leaning phone's
 *  face no longer points down the Z axis, so a straight Z
 *  offset would bury the screen in the body at the top and
 *  float it off at the bottom.
 ***********************************************************/
void PhoneStand::DrawPhone()
{
	glm::vec3 phoneCenter = LeaningCenter(PHONE_SCALE.y, BASE_SCALE.y);

	SetTransformations(
		PHONE_SCALE,
		LEAN_DEGREES,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(phoneCenter, YAW_DEGREES));

	SetShaderColor(0.22f, 0.22f, 0.24f, 1.0f);
	SetShaderMaterial("gloss_plastic");

	m_pShapeMeshes->DrawBoxMesh();

	// the phone's face normal after the lean is applied
	float leanRadians = glm::radians(LEAN_DEGREES);
	glm::vec3 faceNormal = glm::vec3(
		0.0f,
		-std::sin(leanRadians),
		std::cos(leanRadians));

	float screenLift = (PHONE_SCALE.z / 2.0f) + 0.02f;
	glm::vec3 screenCenter = phoneCenter + (faceNormal * screenLift);

	SetTransformations(
		SCREEN_SCALE,
		LEAN_DEGREES,
		YAW_DEGREES,
		0.0f,
		LocalToWorld(screenCenter, YAW_DEGREES));

	// a powered screen showing a dark page, matching the monitor
	SetShaderColor(0.14f, 0.17f, 0.23f, 1.0f);
	SetShaderMaterial("screen_glass");

	m_pShapeMeshes->DrawBoxMesh();
}