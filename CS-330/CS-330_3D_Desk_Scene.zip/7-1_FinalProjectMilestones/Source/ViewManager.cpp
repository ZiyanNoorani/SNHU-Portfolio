///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MILESTONE THREE MODIFICATIONS: Ziyan Noorani
//  The stock template creates a fixed camera and ignores every input device.
//  This version adds the four navigation features the milestone calls for:
//
//    1. WASD keys drive horizontal and depth movement, QE drive vertical
//       movement, all scaled by frame time so speed does not change with
//       frame rate.
//    2. The mouse cursor controls camera orientation through yaw and pitch.
//    3. The scroll wheel raises and lowers travel speed at runtime.
//    4. The P and O keys switch between perspective and orthographic
//       projection while the program is running.
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <cmath>
#include <iostream>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;

	/***********************************************************
	 *  Camera placement constants
	 *
	 *  Two placements are stored rather than one. Perspective
	 *  viewing wants the camera raised and angled down so the
	 *  desk surface reads as a surface. Orthographic viewing
	 *  wants the camera level with the scene and pointed
	 *  straight at it, which is what drops the desk plane out
	 *  of the 2D view: a plane viewed exactly edge on has no
	 *  height on screen.
	 ***********************************************************/

	 // perspective placement, raised above the desk and angled down
	const glm::vec3 PERSPECTIVE_POSITION = glm::vec3(0.0f, 7.0f, 18.0f);
	const float PERSPECTIVE_YAW = -90.0f;
	const float PERSPECTIVE_PITCH = -10.0f;

	// orthographic placement, level with the scene and facing it head on
	const glm::vec3 ORTHOGRAPHIC_POSITION = glm::vec3(0.0f, 4.0f, 18.0f);
	const float ORTHOGRAPHIC_YAW = -90.0f;
	const float ORTHOGRAPHIC_PITCH = 0.0f;

	// half the height of the orthographic viewing volume, in scene units
	const float ORTHOGRAPHIC_VIEW_HEIGHT = 7.5f;

	// field of view used for perspective projection, in degrees
	const float PERSPECTIVE_FIELD_OF_VIEW = 45.0f;

	// near and far clipping planes shared by both projections
	const float NEAR_CLIP_PLANE = 0.1f;
	const float FAR_CLIP_PLANE = 100.0f;

	/***********************************************************
	 *  Navigation tuning constants
	 *
	 *  Speed is bounded on both ends. Without a floor the scroll
	 *  wheel can drive the speed to zero or negative and the
	 *  camera stops responding to the movement keys, which reads
	 *  to the user as a frozen program rather than a slow one.
	 ***********************************************************/
	const float DEFAULT_MOVEMENT_SPEED = 8.0f;
	const float MINIMUM_MOVEMENT_SPEED = 1.0f;
	const float MAXIMUM_MOVEMENT_SPEED = 30.0f;
	const float SPEED_STEP_PER_SCROLL_CLICK = 1.0f;

	// how far the mouse has to travel for a given amount of rotation
	const float MOUSE_SENSITIVITY = 0.08f;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;

	// the four argument camera constructor runs the camera's own
	// vector update, so Front, Right and Up are all consistent with
	// the starting yaw and pitch before the first frame is drawn
	g_pCamera = new Camera(
		PERSPECTIVE_POSITION,
		glm::vec3(0.0f, 1.0f, 0.0f),
		PERSPECTIVE_YAW,
		PERSPECTIVE_PITCH);

	g_pCamera->Zoom = PERSPECTIVE_FIELD_OF_VIEW;
	g_pCamera->MovementSpeed = DEFAULT_MOVEMENT_SPEED;
	g_pCamera->MouseSensitivity = MOUSE_SENSITIVITY;

	bOrthographicProjection = false;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// hide and lock the cursor to the window so it can drive camera
	// orientation without leaving the window or hitting a screen edge
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// this callback is used to receive mouse scroll wheel events
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	// print the control scheme once at startup so the user is not left
	// guessing which keys the scene responds to
	std::cout << "Scene navigation controls" << std::endl;
	std::cout << "  W / S    move forward / backward" << std::endl;
	std::cout << "  A / D    move left / right" << std::endl;
	std::cout << "  Q / E    move up / down" << std::endl;
	std::cout << "  Mouse    look around" << std::endl;
	std::cout << "  Scroll   change movement speed" << std::endl;
	std::cout << "  P        perspective view" << std::endl;
	std::cout << "  O        orthographic view" << std::endl;
	std::cout << "  ESC      exit" << std::endl << std::endl;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 *
 *  GLFW reports an absolute cursor position, but the camera
 *  needs a frame to frame offset, so the previous position is
 *  stored and subtracted. The first report after the cursor is
 *  captured is discarded: the cursor usually jumps a long way
 *  on that first event, and feeding that jump to the camera
 *  would snap the view somewhere unintended.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	if (NULL == g_pCamera)
	{
		return;
	}

	if (gFirstMouse == true)
	{
		gLastX = (float)xMousePos;
		gLastY = (float)yMousePos;
		gFirstMouse = false;
	}

	// horizontal offset drives yaw
	float xOffset = (float)xMousePos - gLastX;
	// vertical offset drives pitch, reversed because window coordinates
	// grow downward while pitch grows upward
	float yOffset = gLastY - (float)yMousePos;

	gLastX = (float)xMousePos;
	gLastY = (float)yMousePos;

	// the camera clamps pitch internally, which stops the view from
	// flipping over when the user drags past straight up or straight down
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  This method is automatically called from GLFW whenever the
 *  mouse scroll wheel is moved.
 *
 *  The wheel adjusts how fast the camera travels rather than
 *  the field of view. A user exploring a scene this size needs
 *  to cross the desk quickly and then slow down to inspect the
 *  mug, and a zoom control cannot do both.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	if (NULL == g_pCamera)
	{
		return;
	}

	float newSpeed = g_pCamera->MovementSpeed + ((float)yOffset * SPEED_STEP_PER_SCROLL_CLICK);

	// clamp so the speed can never reach zero or run away
	if (newSpeed < MINIMUM_MOVEMENT_SPEED)
	{
		newSpeed = MINIMUM_MOVEMENT_SPEED;
	}
	if (newSpeed > MAXIMUM_MOVEMENT_SPEED)
	{
		newSpeed = MAXIMUM_MOVEMENT_SPEED;
	}

	g_pCamera->MovementSpeed = newSpeed;

	// confirm the change, since a speed setting is otherwise invisible
	// until the user presses a movement key
	std::cout << "Camera movement speed: " << newSpeed << std::endl;
}

/***********************************************************
 *  ApplyCameraOrientation()
 *
 *  Rebuilds the camera's Front, Right and Up vectors from a
 *  yaw and pitch pair.
 *
 *  The camera class recalculates these vectors on its own only
 *  when it processes mouse input. Setting the angles directly,
 *  as the projection switch does, would otherwise leave the
 *  camera pointing the old direction until the user moved the
 *  mouse. This method performs the same calculation the camera
 *  uses so the two stay in agreement.
 ***********************************************************/
void ViewManager::ApplyCameraOrientation(float yawDegrees, float pitchDegrees)
{
	if (NULL == g_pCamera)
	{
		return;
	}

	g_pCamera->Yaw = yawDegrees;
	g_pCamera->Pitch = pitchDegrees;

	glm::vec3 front;
	front.x = cos(glm::radians(yawDegrees)) * cos(glm::radians(pitchDegrees));
	front.y = sin(glm::radians(pitchDegrees));
	front.z = sin(glm::radians(yawDegrees)) * cos(glm::radians(pitchDegrees));

	g_pCamera->Front = glm::normalize(front);
	g_pCamera->Right = glm::normalize(glm::cross(g_pCamera->Front, g_pCamera->WorldUp));
	g_pCamera->Up = glm::normalize(glm::cross(g_pCamera->Right, g_pCamera->Front));
}

/***********************************************************
 *  SwitchProjectionMode()
 *
 *  Moves the camera to the placement that suits the requested
 *  projection and records the new mode.
 *
 *  The two projections need different camera placements. A
 *  perspective view is angled down at the desk. An orthographic
 *  view has no vanishing point, so an angled camera turns the
 *  desk plane into a distracting flat band across the image;
 *  looking straight at the scene instead reduces the plane to a
 *  line with no height, which is the result the milestone
 *  describes.
 ***********************************************************/
void ViewManager::SwitchProjectionMode(bool bUsePerspective)
{
	if (NULL == g_pCamera)
	{
		return;
	}

	if (bUsePerspective == true)
	{
		g_pCamera->Position = PERSPECTIVE_POSITION;
		ApplyCameraOrientation(PERSPECTIVE_YAW, PERSPECTIVE_PITCH);
		bOrthographicProjection = false;
		std::cout << "Projection: perspective (3D)" << std::endl;
	}
	else
	{
		g_pCamera->Position = ORTHOGRAPHIC_POSITION;
		ApplyCameraOrientation(ORTHOGRAPHIC_YAW, ORTHOGRAPHIC_PITCH);
		bOrthographicProjection = true;
		std::cout << "Projection: orthographic (2D)" << std::endl;
	}
}

/***********************************************************
 *  ProcessVerticalMovement()
 *
 *  Moves the camera along the world up axis.
 *
 *  Vertical movement is handled here instead of through the
 *  camera's own movement method so that this code does not
 *  depend on which direction values that enumeration happens to
 *  define. Using the world up axis rather than the camera's own
 *  up axis also keeps Q and E moving straight up and down even
 *  when the camera is pitched, which is what a user expects from
 *  a rise and fall control.
 *
 *  verticalDirection is 1.0 for up and -1.0 for down.
 ***********************************************************/
void ViewManager::ProcessVerticalMovement(float verticalDirection)
{
	if (NULL == g_pCamera)
	{
		return;
	}

	float distance = g_pCamera->MovementSpeed * gDeltaTime * verticalDirection;
	g_pCamera->Position += g_pCamera->WorldUp * distance;
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 *
 *  Movement keys are polled rather than handled through a
 *  callback so that holding a key produces smooth continuous
 *  motion instead of the stutter of a key repeat.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	if (NULL == g_pCamera)
	{
		return;
	}

	// --- depth movement: toward and away from the scene ---
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// --- horizontal movement: strafing across the scene ---
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	// --- vertical movement: rising above and dropping below the desk ---
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		ProcessVerticalMovement(1.0f);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		ProcessVerticalMovement(-1.0f);
	}

	// --- projection switching ---
	// the mode is only changed on an actual transition, otherwise holding
	// the key down would reset the camera position every single frame and
	// the user could never move while the key was held
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		if (bOrthographicProjection == true)
		{
			SwitchProjectionMode(true);
		}
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		if (bOrthographicProjection == false)
		{
			SwitchProjectionMode(false);
		}
	}
}

/***********************************************************
 *  BuildProjectionMatrix()
 *
 *  Returns the projection matrix for whichever mode is active.
 *
 *  Both matrices are built from the same aspect ratio and the
 *  same clipping planes, so switching between them changes only
 *  how depth is handled and never how the image is framed
 *  horizontally against vertically.
 ***********************************************************/
glm::mat4 ViewManager::BuildProjectionMatrix() const
{
	float aspectRatio = (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT;

	if (bOrthographicProjection == false)
	{
		// perspective projection: parallel lines converge, so objects
		// further from the camera are drawn smaller
		return(glm::perspective(
			glm::radians(g_pCamera->Zoom),
			aspectRatio,
			NEAR_CLIP_PLANE,
			FAR_CLIP_PLANE));
	}

	// orthographic projection: no convergence, so an object is drawn at
	// the same size no matter how far away it sits. The viewing volume is
	// a box, and its width is derived from the height so the scene is not
	// stretched by the window shape.
	float halfHeight = ORTHOGRAPHIC_VIEW_HEIGHT;
	float halfWidth = ORTHOGRAPHIC_VIEW_HEIGHT * aspectRatio;

	return(glm::ortho(
		-halfWidth, halfWidth,
		-halfHeight, halfHeight,
		NEAR_CLIP_PLANE,
		FAR_CLIP_PLANE));
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing. glfwGetTime returns a double, so the narrowing to
	// float is made explicit rather than left for the compiler to warn about.
	float currentFrame = static_cast<float>(glfwGetTime());
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the
	// event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// define the current projection matrix, which depends on whether
	// the user has selected perspective or orthographic viewing
	projection = BuildProjectionMatrix();

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}