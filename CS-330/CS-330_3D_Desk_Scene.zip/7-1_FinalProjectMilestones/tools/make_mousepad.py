"""
make_mousepad.py
Draws the mousepad texture: white topographic lines on dark cloth.
Every wave uses a whole number of cycles across the image, so it tiles.

Usage: python make_mousepad.py textures/mousepad.png
"""

import sys
import numpy as np
from PIL import Image

SIZE = 1024

rng = np.random.default_rng(42)
coords = np.arange(SIZE) / SIZE
x, y = np.meshgrid(coords, coords)

# height field made of sine waves with whole-number frequencies
field = np.zeros((SIZE, SIZE))
for _ in range(6):
    fx, fy = rng.integers(-4, 5, size=2)
    if fx == 0 and fy == 0:
        fy = 1
    phase = rng.uniform(0, 2 * np.pi)
    field += np.sin(2 * np.pi * (fx * x + fy * y) + phase) / np.hypot(fx, fy)

# contour lines where the field crosses a level, about 1.6 pixels wide
scaled = field * 2.6
gy, gx = np.gradient(scaled)
pixels = np.abs(scaled - np.round(scaled)) / np.maximum(np.hypot(gx, gy), 1e-6)
line = np.clip(2.1 - pixels, 0.0, 1.0)

# dark cloth with a little noise, then the lines on top
cloth = 27.0 + 3.0 * rng.normal(0.0, 1.0, (SIZE, SIZE))
gray = cloth * (1.0 - line) + 222.0 * line
rgb = np.stack([gray, gray + 1.0, gray + 3.0], axis=-1)

Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), "RGB").save(sys.argv[1])
